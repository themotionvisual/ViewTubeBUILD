import React, { useState, useRef, useMemo, useCallback, useEffect } from "react"
import Markdown from "react-markdown"
import { analyzeChannelData } from "../services/gemini"
import Icons from "../components/Icons"
import ReportViewer from "../components/ReportViewer"
import type {
 AppTool,
 CsvFileWithTag,
 CsvUploadType,
 AnalyticsResult,
 ChartConfig,
 AnalysisSection,
} from "../types"
import { useBrain } from "../context/useBrain"
import {
 getMasterRows,
 canonicalRowsToMasterTableRows,
} from "../services/analyticsSelectors"
import {
 collectAvailableCanonicalStats,
 type CanonicalStatKey,
} from "../services/canonicalStatsEngine"
import { UniversalDataTable } from "../components/UniversalDataTable"
import { Database } from "lucide-react"
import {
 buildCsvFilesWithTags,
 expandCsvAndZipFiles,
 getCsvTagColorClass,
 parseCSV as parseCsvRows,
} from "../services/DataEngine"
import {
 LineChart,
 Line,
 XAxis,
 YAxis,
 CartesianGrid,
 Tooltip,
 Legend,
 ResponsiveContainer,
 BarChart,
 Bar,
 ScatterChart,
 Scatter,
 ZAxis,
 RadarChart,
 Radar,
 PolarGrid,
 PolarAngleAxis,
 PolarRadiusAxis,
 ReferenceLine,
 Label,
 Cell,
} from "recharts"
import { Chart } from "react-google-charts"
import {
 RESEARCH_LAB_HEADER_COLORS,
 getChartSpecById,
} from "../chartSystem/unifiedChartSpec"

const GoogleChartWithUnifiedLoader: React.FC<any> = (props) => (
 <Chart {...props} version="current" />
)

const MemoizedGoogleChart = React.memo(
 GoogleChartWithUnifiedLoader,
 (prev: any, next: any) => {
  return (
   prev.data === next.data &&
   prev.options === next.options &&
   prev.chartEvents === next.chartEvents
  )
 },
)

// --- COMPONENT ---
// (Component moved below to original location)

// --- CHART UTILS (Top Level) ---
const getChartData = (chart: ChartConfig, data: any[]): any[] => {
 if (!chart || !data.length) return []

 const firstRow = data[0] || {}
 const availableHeaders = Object.keys(firstRow)

 const videoTitleKey =
  availableHeaders.find((h) => {
   const l = h.toLowerCase()
   return (
    l === "video" ||
    l === "video title" ||
    l === "title" ||
    l.includes("video_title")
   )
  }) || "name"

 const dateKey = availableHeaders.find((h) => {
  const l = h.toLowerCase()
  return l === "date" || l === "publish time" || l.includes("date")
 })

 // UPLOAD FREQUENCY LOGIC: Aggregate by week/month
 if (chart.type === "frequency" && dateKey) {
  const periodMap: Record<
   string,
   { count: number; totalPerf: number; videos: string[] }
  > = {}
  data.forEach((row) => {
   const d = new Date(row[dateKey])
   if (isNaN(d.getTime())) return
   // Group by Week (YYYY-WW)
   const week = `${d.getFullYear()}-W${Math.ceil(d.getDate() / 7)}`
   if (!periodMap[week])
    periodMap[week] = { count: 0, totalPerf: 0, videos: [] }
   periodMap[week].count += 1
   const perfVal = parseFloat(
    String(row[chart.dataKeys?.[0] || "Views"] || "0").replace(/,/g, ""),
   )
   periodMap[week].totalPerf += isNaN(perfVal) ? 0 : perfVal
   periodMap[week].videos.push(row[videoTitleKey] || "Untitled")
  })

  return Object.entries(periodMap)
   .map(([period, stats]) => ({
    period,
    frequency: stats.count,
    performance: stats.totalPerf / stats.count, // Avg per video
    videoTitle: `${stats.count} Videos: ${stats.videos.slice(0, 2).join(", ")}...`,
   }))
   .sort((a, b) => a.period.localeCompare(b.period))
 }

 // Filter by duration type if specified
 let filteredData = [...data]
 if (chart.durationType === "long") {
  filteredData = filteredData.filter((r) => r._userTag === "long")
 } else if (chart.durationType === "shorts") {
  filteredData = filteredData.filter((r) => r._userTag === "shorts")
 }

 // Sort logic
 const primaryKey = chart.dataKeys?.[0]
 let sortedData = filteredData

 if (chart.sortType === "recent" && dateKey) {
  sortedData = [...filteredData].sort(
   (a, b) => new Date(b[dateKey]).getTime() - new Date(a[dateKey]).getTime(),
  )
 } else if (chart.sortType === "alphabetical") {
  sortedData = [...filteredData].sort((a, b) =>
   String(a[videoTitleKey] || "").localeCompare(String(b[videoTitleKey] || "")),
  )
 } else if (chart.sortType === "highest_rated" && primaryKey) {
  sortedData = [...filteredData].sort((a, b) => {
   const valA = parseFloat(String(a[primaryKey] || "0").replace(/,/g, ""))
   const valB = parseFloat(String(b[primaryKey] || "0").replace(/,/g, ""))
   return valB - valA
  })
 } else if (primaryKey) {
  // Default fallback sort
  sortedData = [...filteredData].sort((a, b) => {
   const valA = parseFloat(String(a[primaryKey] || "0").replace(/,/g, ""))
   const valB = parseFloat(String(b[primaryKey] || "0").replace(/,/g, ""))
   return valB - valA
  })
 }

 const limit = chart.videoCount || (chart.type === "radar" ? 15 : 30)
 const rawPoints = sortedData
  .slice(0, limit)
  .map((row) => {
   const point: any = {}
   const xAxisVal =
    row[chart.xAxisKey] || row["Video title"] || row["Date"] || ""
   point[chart.xAxisKey] = xAxisVal
   ;(chart.dataKeys || []).forEach((k: string) => {
    const val = parseFloat(String(row[k] || "0").replace(/,/g, ""))
    point[k] = isNaN(val) ? 0 : val
   })

   if (chart.zAxisKey) {
    const val = parseFloat(String(row[chart.zAxisKey] || "0").replace(/,/g, ""))
    point[chart.zAxisKey] = isNaN(val) ? 0 : val
   }

   point.videoTitle = row[videoTitleKey] || xAxisVal || "Untitled Video"
   point.name = point.videoTitle
   point._userTag = row._userTag
   return point
  })
  .filter((p) => {
   const numericValues = Object.values(p).filter((v) => typeof v === "number")
   return numericValues.length > 0 && !isNaN(numericValues[0] as any)
  })

 // Smart Clipping: Prevent extreme spikes from squashing other data points
 if (primaryKey && rawPoints.length > 5) {
  const values = rawPoints.map((p) => p[primaryKey]).sort((a, b) => a - b)
  const median = values[Math.floor(values.length / 2)]
  const ceiling = median * 10 // Cap at 10x the median

  return rawPoints.map((p) => {
   const val = p[primaryKey]
   if (val > ceiling) {
    return {
     ...p,
     [primaryKey]: ceiling,
     isOutlier: true,
     originalValue: val,
    }
   }
   return p
  })
 }

 return rawPoints
}

// --- CUSTOM TOOLTIP ---
const CustomTooltip = ({ active, payload, label }: any) => {
 if (active && payload && payload.length) {
  return (
   <div className="bg-white border-4 border-black p-4 rounded-xl shadow-[6px_6px_0px_0px_black] z-[200]">
    <p className="text-xs font-black uppercase mb-2 border-b-2 border-dashed border-black pb-1 leading-tight">
     {payload[0].payload.videoTitle || label}
    </p>
    <div className="space-y-1">
     {payload.map((entry: any, index: number) => (
      <div
       key={index}
       className="flex justify-between gap-6 text-[11px] font-bold">
       <span className="uppercase opacity-60">{entry.name}:</span>
       <span className="font-black text-black">
        {typeof entry.value === "number" ?
         entry.value.toLocaleString()
        : entry.value}
        {entry.name.includes("%") ? "%" : ""}
       </span>
      </div>
     ))}
     {payload[0].payload.isOutlier && (
      <p className="text-[9px] font-black text-[#FF7497] uppercase mt-2 italic">
       * Adjusted Outlier (Orig:{" "}
       {payload[0].payload.originalValue.toLocaleString()})
      </p>
     )}
    </div>
   </div>
  )
 }
 return null
}

const formatNumber = (value: number) => {
 if (value >= 1000) {
  return (value / 1000).toFixed(0) + "k"
 }
 return value.toString()
}

const formatMonth = (value: string) => {
 const date = new Date(value)
 if (isNaN(date.getTime())) return value
 return date.toLocaleString("default", { month: "short" })
}

// --- GOOGLE CHART RENDERING ---
const RenderGoogleChart: React.FC<{ chart: ChartConfig; data: any[] }> = ({
 chart,
 data,
}) => {
 const typeKey = String(chart.type || "")
  .trim()
  .toLowerCase()

 const googleData = useMemo(() => {
  if (typeof chart.data === "function") {
   const result = chart.data()
   if (result) return result
  }
  return data || []
 }, [chart, data])

 if (typeKey === "geographysplitview") {
  return (
   <div className="w-full h-full flex flex-col p-4 bg-white border-4 border-black rounded-2xl overflow-hidden">
    <Chart
     chartType="GeoChart"
     width="100%"
     height="100%"
     data={googleData as any}
     options={{
      keepAspectRatio: true,
      chartArea: { width: "95%", height: "95%" },
      colorAxis: {
       colors: ["#00CCFF", "#CCFF00", "#FFDD00", "#FFB158", "#FF7497"],
      },
      datalessRegionColor: "#f5f5f5",
      backgroundColor: "transparent",
     }}
    />
   </div>
  )
 }

 if (typeKey === "topperformerstrio") {
  return (
   <div className="grid grid-cols-3 gap-6 h-full p-4 overflow-y-auto">
    <TrioPieCard
     chart={{ title: "REVENUE", data: (googleData as any)?.moneyMakers || [] }}
    />
    <TrioPieCard
     chart={{
      title: "WATCH HOURS",
      data: (googleData as any)?.mostViewed || [],
     }}
    />
    <TrioPieCard
     chart={{ title: "SUBS", data: (googleData as any)?.newSubs || [] }}
    />
   </div>
  )
 }

 const chartTypeMap: any = {
  line: "LineChart",
  bar: "BarChart",
  column: "ColumnChart",
  scatter: "ScatterChart",
  bubble: "BubbleChart",
  pie: "PieChart",
  geo: "GeoChart",
  geochart: "GeoChart",
  combo: "ComboChart",
  combochart: "ComboChart",
  steppedarea: "SteppedAreaChart",
  steppedareachart: "SteppedAreaChart",
  treemap: "TreeMap",
  contenttypedistribution: "PieChart",
  candlestick: "CandlestickChart",
  candlestickchart: "CandlestickChart",
 }

 return (
  <Chart
   chartType={chartTypeMap[typeKey] || "LineChart"}
   width="100%"
   height="100%"
   data={googleData as any}
   options={{
    backgroundColor: "transparent",
    chartArea: { width: "95%", height: "80%", left: "5%", top: "10%" },
    colors: ["#10B981", "#4F46E5", "#FF7497", "#FFDD00", "#FFB158", "#B14AED"],
    ...chart.options,
   }}
  />
 )
}

// --- CUSTOM CHART SUB-COMPONENTS ---
const TrioPieCard = ({
 chart,
 colors,
 pieStartAngle = 0,
 height = "240px",
}: {
 chart: { title: string; data: any[] }
 colors?: string[]
 pieStartAngle?: number
 height?: string
}) => {
 const topSlice = useMemo(() => {
  if (!chart.data || chart.data.length <= 1) return null
  const slices = [...chart.data.slice(1)]
  slices.sort((a, b) => {
   const vA = typeof a[1] === "object" ? a[1].v : a[1]
   const vB = typeof b[1] === "object" ? b[1].v : b[1]
   return vB - vA
  })
  return slices[0]
 }, [chart.data])

 const [displaySlice, setDisplaySlice] = useState<any>(topSlice)

 const chartOptions = {
  legend: { position: "none" },
  backgroundColor: "transparent",
  colors: colors || [
   "#00CCFF",
   "#CCFF00",
   "#FFDD00",
   "#FFB158",
   "#FF7497",
   "#FF87F3",
  ],
  pieHole: 0.5,
  chartArea: { width: "88%", height: "88%", left: "6%", top: "6%" },
  pieSliceText: "value",
  pieSliceTextStyle: {
   color: "white",
   fontSize: 13,
   fontName: "Inter",
   bold: true,
  },
  pieStartAngle: pieStartAngle,
  tooltip: { trigger: "none" },
 }

 const chartEvents = [
  {
   eventName: "ready",
   callback: ({ chartWrapper, google }: any) => {
    const c = chartWrapper.getChart()
    google.visualization.events.addListener(c, "onmouseover", (e: any) => {
     if (e && e.row !== null) setDisplaySlice(chart.data[e.row + 1])
    })
   },
  },
 ]

 return (
  <div
   className="flex flex-col items-center justify-center p-0 transition-all group/trio origin-center w-full"
   style={{ height: height }}>
   <div className="w-full h-full pointer-events-auto relative">
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
     <span className="text-[14px] font-black uppercase text-black max-w-[80px] text-center leading-none tracking-tighter group-hover/trio:scale-110 transition-transform">
      {chart.title}
     </span>
    </div>
    <Chart
     chartType="PieChart"
     width="100%"
     height="100%"
     data={chart.data}
     options={chartOptions as any}
     chartEvents={chartEvents as any}
    />
   </div>
   {height !== "200px" && displaySlice && (
    <div className="flex flex-col items-center justify-center -mt-16 px-4">
     <span className="text-[12px] font-black text-black/50 uppercase tracking-widest leading-none mb-1 line-clamp-3 w-[260px] text-center">
      {displaySlice[0]}
     </span>
     <span className="text-[20px] font-black text-indigo-500 tracking-tighter leading-none">
      {typeof displaySlice[1] === "object" ?
       displaySlice[1].f || displaySlice[1].v
      : displaySlice[1].toLocaleString()}
     </span>
    </div>
   )}
  </div>
 )
}
// --- CHART RENDERING ENGINE (Top Level) ---
const RenderChart: React.FC<{
 chart: ChartConfig
 data?: any[]
 isModal?: boolean
 fallbackData?: any[]
 dataDateRange?: string
}> = ({
 chart,
 data,
 isModal = false,
 fallbackData = [],
 dataDateRange = "",
}) => {
 const chartData = data && data.length > 0 ? data : fallbackData
 const provider = String(chart.provider || "google").toLowerCase()
 const isKnownProvider = provider === "google" || provider === "recharts"
 const missingMetrics = chart.missingMetrics || []
 const hasMissingRequiredMetrics =
  Array.isArray(chart.requiredMetrics) && missingMetrics.length > 0
 const rawType = String(chart.type || "")
  .trim()
  .toLowerCase()

 // 1. ELITE HTML TABLE OVERRIDE (Requirement: Fix 'table' errors permanently)
 if (rawType === "table") {
  const tableData = typeof chart.data === "function" ? chart.data() : []
  const hasData = tableData.length > 1

  return (
   <div
    className={`w-full flex flex-col ${isModal ? "h-full" : "h-[400px] mt-2 bg-white border-2 border-black rounded-xl overflow-hidden shadow-[4px_4px_0px_0px_black]"}`}>
    <div className="flex-1 min-h-0 overflow-auto bg-gray-50/20">
     <table className="w-full text-left text-[11px] font-black border-collapse">
      <thead className="sticky top-0 bg-black text-white z-10">
       <tr>
        {(hasData ? tableData[0] : ["METRIC", "VALUE"]).map(
         (h: any, i: number) => (
          <th
           key={i}
           className="p-3 border-r border-white/10 uppercase tracking-tighter whitespace-nowrap">
           {String(h)}
          </th>
         ),
        )}
       </tr>
      </thead>
      <tbody>
       {(hasData ? tableData.slice(1) : [["NO DATA DETECTED", "0"]]).map(
        (row: any, i: number) => (
         <tr
          key={i}
          className={`border-b border-black/5 ${i % 2 === 0 ? "bg-white" : "bg-gray-50/50"} hover:bg-[#FFDD00]/20`}>
          {row.map((cell: any, j: number) => (
           <td key={j} className="p-3 border-r border-black/5 tabular-nums">
            {typeof cell === "number" ?
             cell > 1 ?
              cell.toLocaleString()
             : cell.toFixed(3)
            : String(cell || "")}
           </td>
          ))}
         </tr>
        ),
       )}
      </tbody>
     </table>
    </div>
   </div>
  )
 }

 if (hasMissingRequiredMetrics) {
  return (
   <div className="p-8 text-center font-black opacity-70 uppercase">
    <div>Data Missing For This Chart</div>
    <div className="mt-2 text-[10px] opacity-70 normal-case">
     Missing: {missingMetrics.join(", ")}
    </div>
   </div>
  )
 }

 // 2. DATA LOAD VERIFICATION
 if (!chartData || chartData.length === 0) {
  if (provider === "google" || provider === "recharts" || !chart.provider) {
   const checkData = typeof chart.data === "function" ? chart.data() : []
   if (checkData.length <= 1)
    return (
     <div className="p-8 text-center font-black opacity-20 uppercase">
      Station Idle: No Dataset
     </div>
    )
  } else {
   return (
    <div className="p-8 text-center font-black opacity-20 uppercase">
     Station Idle: No dataset
    </div>
   )
  }
 }

 return (
  <div
   className={`w-full flex flex-col ${isModal ? "h-full" : "h-[450px] mt-6 bg-white border-3 border-black rounded-2xl shadow-[8px_8px_0px_0px_black] overflow-hidden"}`}>
   <div className="flex-1 min-h-0">
    {isKnownProvider ?
     <RenderGoogleChart chart={chart} data={chartData} />
    : <div className="p-8 text-center font-black">Unknown Provider: {provider}</div>}
   </div>

   <div className="bg-black text-white px-4 py-2 text-[10px] font-black uppercase tracking-widest flex justify-between items-center border-t-2 border-black">
    <div className="flex items-center gap-4">
     <span className="text-[#FFDD00]">{chart.title}</span>
     <span className="opacity-40">|</span>
     <span>{chartData.length} Records</span>
    </div>
    {dataDateRange && <span className="text-[#FF7497]">{dataDateRange}</span>}
   </div>
  </div>
 )
}

const engagementMetrics = ["Comments", "Subscribers", "Shares", "Likes"]
const metricColors: Record<string, string> = {
 Comments: "#00CCFF",
 Subscribers: "#CCFF00",
 Shares: "#FFDD00",
 Likes: "#FF7497",
}

const StationCard = ({
 cfg,
 index,
 headerColors,
 rowIdx,
 engagementSortBy,
 setEngagementSortBy,
 engagementMetrics,
 metricColors,
 setActiveChart,
 videoOnlyData,
 titleKey,
 selectedSoloVideoId,
 setSelectedSoloVideoId,
 setExcludedOutliers,
 ctrKey,
 apvKey,
 viewsKey,
}: any) => {
 const [hovered, setHovered] = useState<any>(null)
 const clickTimes = useRef<number[]>([])

 const currentData = useMemo(() => {
  try {
   return cfg.data() || []
  } catch (e) {
   console.warn("Station data error:", cfg.title, e)
   return []
  }
 }, [cfg])

 const isValueMatrix = cfg.title === "Video Value Matrix"
 const isEngagementRanker =
  cfg.title === "Engagement Map" || cfg.title.includes("Engagement Ranker")
 const isContentTypeDistribution = cfg.type === "ContentTypeDistribution"
 const isTopPerformersTrio = cfg.type === "TopPerformersTrio"
 const isGeographySplitView = cfg.type === "GeographySplitView"
 const isFullWidth =
  isValueMatrix ||
  isEngagementRanker ||
  isContentTypeDistribution ||
  isTopPerformersTrio ||
  isGeographySplitView ||
  cfg.type === "LineChart" ||
  cfg.title === "Hook-to-Binge Funnel"

 const isPieChart = cfg.type === "PieChart"
 // const isBoxedChart = cfg.type === "ScatterChart" || cfg.type === "BubbleChart"; // Removed unused variable

 const headerColor = headerColors[rowIdx % headerColors.length]

 const chartOptions = useMemo(() => {
  const baseArea =
   (cfg.options as any)?.chartArea ||
   (isFullWidth ?
    { left: 100, right: 80, top: 15, bottom: isEngagementRanker ? 50 : 30 }
   : { left: 60, right: 60, top: 15, bottom: 30 })

  return {
   legend: { position: "none" },
   chartArea: {
    ...baseArea,
    backgroundColor: "transparent",
    stroke: "none",
   },
   backgroundColor: "transparent",
   tooltip:
    (
     isPieChart || isEngagementRanker /* || isBoxedChart */ // Removed isBoxedChart
    ) ?
     { trigger: "none" }
    : {
      isHtml: false,
      textStyle: {
       fontSize: 13,
       fontName: "Inter",
       bold: true,
       color: "#000000",
      },
     },
   hAxis: {
    gridlines: { color: "#f0f0f0" },
    baselineColor: "#000",
    ...(cfg.options as any)?.hAxis,
    textStyle: {
     fontSize: 14,
     fontName: "Inter",
     bold: true,
     color: "#000",
     ...(cfg.options as any)?.hAxis?.textStyle,
    },
    titleTextStyle: {
     fontSize: 16,
     fontName: "Inter",
     bold: true,
     color: "#000",
     ...(cfg.options as any)?.hAxis?.titleTextStyle,
    },
   },
   vAxis: {
    gridlines: { color: "#f0f0f0" },
    baselineColor: "#000",
    format: "short",
    ...(cfg.options as any)?.vAxis,
    textStyle: {
     fontSize: 13,
     fontName: "Inter",
     bold: true,
     color: "#000",
     ...(cfg.options as any)?.vAxis?.textStyle,
    },
    titleTextStyle: {
     fontSize: 16,
     fontName: "Inter",
     bold: true,
     color: "#000",
     ...(cfg.options as any)?.vAxis?.titleTextStyle,
    },
   },
   ...((cfg.options as any)?.vAxes ?
    { vAxes: (cfg.options as any).vAxes }
   : {}),
   ...(isPieChart ?
    {
     pieSliceText: "value",
     pieSliceBorderColor: "transparent",
     pieSliceTextStyle: {
      color: "white",
      fontSize: 16,
      fontName: "Inter",
      bold: true,
      ...(cfg.options as any)?.pieSliceTextStyle,
     },
    }
   : {}),
   ...cfg.options,
   ...(isPieChart || isEngagementRanker /* || isBoxedChart */ ?
    { tooltip: { trigger: "none" } }
   : {}), // Removed isBoxedChart
   animation: { duration: isEngagementRanker ? 500 : 0, easing: "out" }, // Re-enable for Engagement Ranker
   enableInteractions: true,
  }
 }, [cfg, isPieChart, isEngagementRanker, isFullWidth]) // Removed isBoxedChart

 const chartEvents = useMemo(() => {
  if (!isPieChart && !isEngagementRanker /* && !isBoxedChart */) return [] // Removed isBoxedChart
  return [
   {
    eventName: "ready" as any,
    callback: ({ chartWrapper, google }: any) => {
     const chart = chartWrapper.getChart()
     google.visualization.events.addListener(chart, "onmouseover", (e: any) => {
      if (e.row !== null && currentData[e.row + 1]) {
       const rowData = currentData[e.row + 1]
       if (isPieChart) {
        setHovered({
         title: rowData[0],
         value: rowData[1],
         color: [
          "#00CCFF",
          "#CCFF00",
          "#FFDD00",
          "#FFB158",
          "#FF7497",
          "#FF87F3",
         ][e.row % 6],
        })
       } else {
        // Robust Label Extraction
        let rowTitle = String(rowData[0] || "")
        let rowStats: any[] = []
        // Look for tooltip Role or longest name-like string
        const possibleTooltip = rowData.find(
         (cell: any) => typeof cell === "string" && cell.includes("\n"),
        )
        if (possibleTooltip) {
         const lines = possibleTooltip.split("\n")
         rowTitle = lines[0]
         rowStats = lines.slice(1)
        } else {
         // Fallback: If row[0] is a number (common in Scatter), use the next string
         if (typeof rowData[0] === "number") {
          const secondStr = rowData.find(
           (cell: any, i: number) =>
            i > 0 &&
            typeof cell === "string" &&
            !String(cell).startsWith("point {"),
          )
          if (secondStr) rowTitle = secondStr
         }
        }
        setHovered({
         title: rowTitle,
         value: rowData[1],
         stats: rowStats,
         color: "#00CCFF",
         row: e.row,
        })
       }
      }
     })
     google.visualization.events.addListener(chart, "onmouseout", () =>
      setHovered(null),
     )
    },
   },
   {
    eventName: "select" as any,
    callback: ({ chartWrapper }: any) => {
     if (cfg.title !== "Viewer Loyalty") return
     const chart = chartWrapper.getChart()
     const selection = chart.getSelection()
     if (selection.length > 0 && selection[0].row !== null) {
      const now = Date.now()
      clickTimes.current = [
       ...clickTimes.current.filter((t) => now - t < 1000),
       now,
      ]
      if (clickTimes.current.length >= 3) {
       const rowIdx = selection[0].row
       const videoId = currentData[rowIdx + 1][0] // ID is in col 0
       if (videoId) {
        setExcludedOutliers?.((prev: Set<string>) => {
         const next = new Set(prev)
         next.add(videoId)
         return next
        })
        clickTimes.current = []
       }
      }
     }
    },
   },
  ]
 }, [isPieChart, isEngagementRanker, currentData]) // Removed isBoxedChart

 const isWaiting = currentData.length < 2
 const topItem = currentData.length > 1 ? currentData[1] : null

 const displayTitleRaw =
  hovered ? hovered.title
  : topItem ? topItem[0]
  : "Hover slice to view"
 const displayTitle =
  displayTitleRaw instanceof Date ? displayTitleRaw.toLocaleDateString()
  : typeof displayTitleRaw === "object" && displayTitleRaw !== null ?
   String(displayTitleRaw.f || displayTitleRaw.v || "")
  : displayTitleRaw
 const displayStatRaw =
  hovered ? hovered.value
  : topItem ? topItem[1]
  : ""
 const displayStat =
  typeof displayStatRaw === "object" && displayStatRaw !== null ?
   (displayStatRaw as any).f || (displayStatRaw as any).v
  : typeof displayStatRaw === "number" ? displayStatRaw.toLocaleString()
  : displayStatRaw

 return (
  <div
   className={`pop-box relative flex flex-col ${isTopPerformersTrio ? "min-h-[660px]" : "h-[500px]"} overflow-hidden group ${isTopPerformersTrio || isPieChart ? "bg-white" : ""} ${isFullWidth ? "lg:col-span-2" : ""} rounded-2xl border-[5px] border-black leading-none`}>
   <div
    className="border-b-[5px] border-black flex items-stretch justify-between transition-colors relative overflow-hidden pl-4 !pr-0 !py-0"
    style={{ backgroundColor: headerColor }}>
    <div className="flex flex-col flex-1 min-w-0 justify-center py-2">
     <div className="flex items-center gap-4">
      <h4 className="text-[20px] font-black uppercase tracking-tight leading-none break-words xl:text-[22px]">
       {cfg.title}
      </h4>
      {cfg.title === "Viewer Loyalty" &&
       (() => {
        // Calculate totals for Loyalty header
        const rows = currentData.slice(1)
        const totalNew = rows.reduce(
         (acc: number, r: any) =>
          acc + (parseFloat(String(r[1]).replace(/,/g, "")) || 0),
         0,
        )
        const totalRet = rows.reduce(
         (acc: number, r: any) =>
          acc + (parseFloat(String(r[2]).replace(/,/g, "")) || 0),
         0,
        )
        return (
         <div className="flex items-center gap-3 bg-white/20 px-3 py-1 rounded-full border border-black/10">
          <div className="flex flex-col items-center">
           <span className="text-[14px] font-black text-black leading-none">
            {totalNew.toLocaleString()}
           </span>
           <span className="text-[7px] font-black opacity-40 uppercase tracking-widest">
            NEW
           </span>
          </div>
          <div className="w-[1px] h-4 bg-black/10" />
          <div className="flex flex-col items-center">
           <span className="text-[14px] font-black text-black leading-none">
            {totalRet.toLocaleString()}
           </span>
           <span className="text-[7px] font-black opacity-40 uppercase tracking-widest">
            RETURNING
           </span>
          </div>
         </div>
        )
       })()}
     </div>
     <span className="text-[10px] font-black text-black/50 uppercase tracking-[0.2em] leading-none mt-1 xl:text-[11px]">
      {cfg.subtitle}
     </span>
    </div>
    <div className="flex items-stretch shrink-0 gap-4 pr-4">
     {cfg.title === "Video Value Matrix" &&
      selectedSoloVideoId &&
      (() => {
       const video = videoOnlyData.find((v) => v._id === selectedSoloVideoId)
       if (!video) return null
       const ctr = parseFloat(String(video[ctrKey]).replace(/,/g, "")) || 0
       const apv = parseFloat(String(video[apvKey]).replace(/,/g, "")) || 0
       const views = parseFloat(String(video[viewsKey]).replace(/,/g, "")) || 0
       return (
        <div className="flex items-center gap-4 bg-black/5 px-4 my-2 border-l-4 border-black/10">
         <div className="flex flex-col items-end">
          <span className="text-[16px] font-black text-black leading-none">
           {views.toLocaleString()}
          </span>
          <span className="text-[8px] font-black opacity-40 uppercase tracking-widest">
           VIEWS
          </span>
         </div>
         <div className="flex flex-col items-end">
          <span className="text-[16px] font-black text-black leading-none">
           {ctr.toFixed(1)}%
          </span>
          <span className="text-[8px] font-black opacity-40 uppercase tracking-widest">
           CTR
          </span>
         </div>
         <div className="flex flex-col items-end">
          <span className="text-[16px] font-black text-black leading-none">
           {apv.toFixed(0)}%
          </span>
          <span className="text-[8px] font-black opacity-40 uppercase tracking-widest">
           RETENTION
          </span>
         </div>
        </div>
       )
      })()}
     <div className="flex items-center gap-4 py-1.5 pr-4">
      {/* Sorting buttons moved to footer */}
      {cfg?.title?.startsWith("Solo") ?
       <div className="flex bg-[#CCFF00] rounded-lg border-2 border-black shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] min-w-[50px] overflow-hidden">
        <div className="px-2 py-1 flex items-center justify-center border-r-[2px] border-black shrink-0">
         <span className="text-[12px] font-black text-black leading-none tracking-tight">
          SOLO
         </span>
        </div>
        <select
         value={selectedSoloVideoId || ""}
         onChange={(e) => setSelectedSoloVideoId(e.target.value)}
         className="bg-transparent font-black max-w-[140px] text-[10px] outline-none px-2 uppercase truncate cursor-pointer hover:bg-black/5">
         <option value="">LATEST / TOP</option>
         {(videoOnlyData || []).slice(0, 50).map((v: any, idx: number) => (
          <option key={v._id || idx} value={v._id}>
           {String(v[titleKey] || "Unknown Video").substring(0, 40)}
          </option>
         ))}
        </select>
       </div>
      : <div className="bg-black rounded-lg px-3 py-1 flex flex-col items-center justify-center border-2 border-black whitespace-nowrap shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] min-w-[50px]">
        <span className="text-[18px] font-black text-white leading-none tracking-tight">
         {Math.max(0, (currentData?.length || 0) - 1)}
        </span>
        <span className="text-[9px] font-black text-[#CCFF00] uppercase tracking-widest leading-none mt-1">
         {cfg.isEngagementRanker || cfg.id?.includes("top") ?
          "HIGHEST"
         : "LATEST"}
        </span>
       </div>
      }
     </div>
     <button
      onClick={() => setActiveChart(cfg)}
      className="aspect-square bg-[#FF7497] border-l-[5px] border-black flex items-center justify-center hover:bg-black hover:text-[#FF7497] transition-all group/expand overflow-hidden cursor-pointer shrink-0">
      <svg
       width="24"
       height="24"
       viewBox="0 0 24 24"
       fill="none"
       stroke="currentColor"
       strokeWidth="4"
       strokeLinecap="round"
       strokeLinejoin="round"
       className="text-black group-hover:text-[#FF7497] group-hover:scale-110 transition-transform">
       <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" />
      </svg>
     </button>
    </div>
   </div>

   {(isPieChart /* || isBoxedChart */ || isEngagementRanker) && ( // Removed isBoxedChart
    <div className="px-5 py-1 flex items-center justify-between border-b-[6px] border-black bg-white h-[56px] shadow-[inset_0_4px_10px_rgba(0,0,0,0.05)] gap-4 overflow-hidden relative">
     <div className="flex items-center gap-3 flex-1 min-w-0">
      <div
       className="w-5 h-5 rounded-full flex-shrink-0 animate-pulse border-[3px] border-black"
       style={{ backgroundColor: hovered?.color || "#000" }}
      />
      <span className="text-[21px] font-black uppercase tracking-tight text-black flex-1 break-words py-0.5 line-clamp-2 leading-tight">
       {displayTitle === "Hover slice to view" ?
        "SELECT DATA POINT"
       : displayTitle}
      </span>
      {isEngagementRanker && (
       <>
        <div className="h-6 w-[2px] bg-black/10 mx-4" />
        <div className="flex items-center gap-4 flex-1 justify-end pr-4">
         {[
          {
           label: "LIKES",
           color: "#FF7497",
           val:
            hovered?.row !== undefined ?
             (currentData as any)[hovered.row + 1]?.[1]
            : topItem?.[1],
          },
          {
           label: "COMMENTS",
           color: "#CCFF00",
           val:
            hovered?.row !== undefined ?
             (currentData as any)[hovered.row + 1]?.[2]
            : topItem?.[2],
          },
          {
           label: "SHARES",
           color: "#FFDD00",
           val:
            hovered?.row !== undefined ?
             (currentData as any)[hovered.row + 1]?.[3]
            : topItem?.[3],
          },
          {
           label: "SUBS",
           color: "#00CCFF",
           val:
            hovered?.row !== undefined ?
             (currentData as any)[hovered.row + 1]?.[4]
            : topItem?.[4],
          },
         ].map((stat, sIdx) => (
          <div
           key={sIdx}
           className="flex flex-col items-center justify-center min-w-[80px]">
           <span className="text-[18px] font-black text-black tracking-tighter tabular-nums leading-none">
            {typeof stat.val === "object" ?
             stat.val?.f || stat.val?.v
            : stat.val?.toLocaleString() || "0"}
           </span>
           <span className="text-[9px] font-black text-black/40 tracking-[0.2em] uppercase mt-1">
            {stat.label}
           </span>
          </div>
         ))}
        </div>
       </>
      )}
     </div>
     {!isEngagementRanker && (
      <div className="flex flex-col items-end flex-shrink-0 leading-none justify-center">
       <span className="text-[10px] font-black text-black/40 uppercase tracking-widest">
        {currentData[0]?.[1] || "METRIC"}
       </span>
       <span className="text-[22px] font-black text-indigo-500 tracking-tighter mt-1">
        {displayStat}
       </span>
      </div>
     )}
    </div>
   )}

   <div className="flex-1 min-h-0 bg-white p-6 relative">
    {isWaiting ?
     <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/50 backdrop-blur-sm z-20">
      <div className="w-8 h-8 border-4 border-black border-t-[#CCFF00] rounded-full animate-spin mb-3"></div>
      <span className="text-[10px] font-black uppercase tracking-[0.3em] text-black/40">
       Synchronizing Data...
      </span>
     </div>
    : <div className="w-full h-full relative">
      {cfg.title === "Video Value Matrix" ?
       <div className="flex flex-row h-full w-full overflow-hidden">
        {/* Left: Video Bubbles */}
        <div className="w-[30%] h-full flex flex-col p-4 border-r-4 border-black/5 overflow-y-auto custom-scrollbar">
         <span className="font-black text-[10px] text-black/30 uppercase mb-4 text-center tracking-[0.2em]">
          Top 25 Videos Impact
         </span>
         <div className="grid grid-cols-4 gap-3">
          {Array.isArray(currentData) &&
           (() => {
            const rows = currentData.slice(1, 26)
            const maxViews = Math.max(...rows.map((r: any) => r[4] || 0))
            return rows.map((row: any, ri: number) => {
             const views = row[4] || 0
             const sizeRatio = 0.5 + (views / (maxViews || 1)) * 0.5
             const bubbleSize = 40 * sizeRatio
             return (
              <div
               key={ri}
               className="group/video relative aspect-square rounded-full border-2 border-black flex items-center justify-center hover:bg-black transition-all cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
               style={{
                width: bubbleSize,
                height: bubbleSize,
                backgroundColor: row[3] === "Shorts" ? "#FF7497" : "#00CCFF",
               }}
               onClick={() => {
                // Find original video ID if possible, or just scroll/zoom
               }}>
               <span className="text-[8px] font-black group-hover:text-white transition-colors">
                V{ri + 1}
               </span>
               <div className="absolute -top-16 left-1/2 -translate-x-1/2 bg-black text-white px-3 py-2 rounded text-[10px] whitespace-nowrap opacity-0 group-hover/video:opacity-100 transition-opacity z-50 shadow-xl border border-white/20">
                <p className="font-black text-[#CCFF00] mb-1">POS #{ri + 1}</p>
                <p className="opacity-70">VIEWS: {views.toLocaleString()}</p>
                <p className="opacity-70">
                 CTR: {row[1]}% | RET: {row[2]}%
                </p>
               </div>
              </div>
             )
            })
           })()}
         </div>
        </div>
        {/* Right: Matrix */}
        <div className="w-[70%] h-full relative">
         {/* Quadrant Background/Labels */}
         <div className="absolute inset-x-[15%] inset-y-[15%] pointer-events-none grid grid-cols-2 grid-rows-2 z-0">
          <div className="flex items-start justify-start p-6">
           <span className="text-black/10 font-black text-3xl uppercase tracking-widest textShadow-white">Hidden Gem</span>
          </div>
          <div className="flex items-start justify-end p-6">
           <span className="text-black/10 font-black text-3xl uppercase tracking-widest textShadow-white">Gold Mine</span>
          </div>
          <div className="flex items-end justify-start p-6">
           <span className="text-black/10 font-black text-3xl uppercase tracking-widest textShadow-white">Graveyard</span>
          </div>
          <div className="flex items-end justify-end p-6">
           <span className="text-black/10 font-black text-3xl uppercase tracking-widest textShadow-white">Click Bait</span>
          </div>
         </div>
         <div className="absolute inset-0 z-10 pointer-events-auto">
          <MemoizedGoogleChart
           chartType={cfg.type as any}
           width="100%"
           height="100%"
           data={currentData}
           options={{...chartOptions, backgroundColor: 'transparent'}}
           chartEvents={chartEvents as any}
          />
         </div>
        </div>
       </div>
      : isGeographySplitView ?
       <div className="flex flex-row h-full w-full overflow-hidden">
        {/* Left: Bubble Grid */}
        <div className="w-[45%] h-full flex flex-col p-4 border-r-4 border-black/5 overflow-y-auto custom-scrollbar">
         <span className="font-black text-[12px] text-black/30 uppercase mb-6 text-center tracking-[0.3em]">
          Top 25 Global Markets
         </span>
         <div className="grid grid-cols-5 gap-y-8 gap-x-4">
          {Array.isArray(currentData) &&
           (() => {
            const rows = currentData.slice(1, 26)
            const maxViews = Math.max(...rows.map((r: any) => r[1] || 0))
            return rows.map((row: any, ri: number) => {
             const views = row[1] || 0
             const sizeRatio = 0.4 + (views / (maxViews || 1)) * 0.6
             const bubbleSize = 50 * sizeRatio
             return (
              <div key={ri} className="flex flex-col items-center">
               <div
                className="group/geo relative rounded-full border-2 border-black flex items-center justify-center hover:bg-black transition-all cursor-crosshair shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                style={{
                 width: bubbleSize,
                 height: bubbleSize,
                 backgroundColor: headerColors[ri % headerColors.length],
                }}>
                <span className="text-[10px] font-black group-hover:text-white transition-colors">
                 {String(row[0] || "??")
                  .slice(0, 2)
                  .toUpperCase()}
                </span>
                <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-black text-white px-2 py-1 rounded text-[10px] whitespace-nowrap opacity-0 group-hover/geo:opacity-100 transition-opacity z-50">
                 {row[0]}:{" "}
                 <span className="text-[#CCFF00] font-black">
                  {views.toLocaleString()}
                 </span>
                </div>
               </div>
               <span className="mt-2 text-[9px] font-black uppercase text-black/60 tracking-tighter text-center leading-none truncate w-full">
                {row[0]}
               </span>
              </div>
             )
            })
           })()}
         </div>
        </div>
        {/* Right: Map */}
        <div className="w-[65%] h-full">
         <MemoizedGoogleChart
          chartType="GeoChart"
          width="100%"
          height="100%"
          data={currentData}
          options={{
           ...chartOptions,
           keepAspectRatio: true,
           chartArea: { width: "95%", height: "95%" },
           colorAxis: {
            colors: ["#00CCFF", "#CCFF00", "#FFDD00", "#FFB158", "#FF7497"],
           },
           datalessRegionColor: "#f5f5f5",
           backgroundColor: "transparent",
          }}
         />
        </div>
       </div>
      : isTopPerformersTrio ?
       <div className="w-full h-full relative pt-0 pb-1 px-0 flex flex-col items-center">
        {/* Olympic Row 1: 4 Trend Satellites - 12 Column System */}
        <div className="grid grid-cols-12 gap-0 z-20 w-full relative">
         {((currentData as any)?.trends || []).map(
          (chart: any, idx: number) => (
           <div key={`trend-${idx}`} className="col-span-3 flex justify-center">
            <div className="w-full max-w-[220px]">
             <TrioPieCard
              height="220px"
              colors={["#FF7497", "#00CCFF"]}
              pieStartAngle={(() => {
               const total = chart.data
                .slice(1)
                .reduce((acc: number, r: any) => acc + (r[1] || 0), 0)
               const s1 = chart.data[1][1] || 0
               return -((s1 / (total || 1)) * 360) / 2
              })()}
              chart={{ title: chart.label, data: chart.data }}
             />
            </div>
           </div>
          ),
         )}
        </div>

        {/* Olympic Row 2: 3 Hero Trio - FLEX Centered for Perfect Interleaving */}
        <div className="flex justify-center gap-1 z-10 w-full -mt-24 relative mr-12">
         {[
          { title: "REVENUE", data: (currentData as any)?.moneyMakers || [] },
          {
           title: "WATCH HOURS",
           data: (currentData as any)?.mostViewed || [],
          },
          { title: "SUBS", data: (currentData as any)?.newSubs || [] },
         ].map((chart, idx) => (
          <div key={`trio-${idx}`} className="w-full max-w-[420px]">
           <TrioPieCard height="440px" chart={chart} />
          </div>
         ))}
        </div>
       </div>
      : isContentTypeDistribution ?
       <div className="w-full h-full overflow-y-auto custom-scrollbar pr-2">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-2">
         {(Array.isArray(currentData) ? currentData : []).map(
          (donut: any, idx: number) => {
           const donutData =
            typeof donut.data === "function" ? donut.data() : donut.data || []
           const total = donutData
            .slice(1)
            .reduce((acc: number, r: any) => acc + (r[1] || 0), 0)
           return (
            <div
             key={idx}
             className="flex flex-col bg-white border-2 border-black/5 rounded-[2rem] p-5 shadow-sm hover:border-black/20 transition-all group/donut-card">
             <div className="relative aspect-square mb-4">
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-10 scale-90 group-hover/donut-card:scale-100 transition-transform">
               <span className="text-[10px] font-black text-black/30 uppercase tracking-[0.2em] mb-1">
                {donut.label}
               </span>
               <span className="text-[18px] font-black text-black tracking-tighter leading-none">
                {total.toLocaleString()}
               </span>
              </div>
              <MemoizedGoogleChart
               chartType="PieChart"
               width="100%"
               height="100%"
               data={donutData}
               options={{
                legend: { position: "none" },
                backgroundColor: "transparent",
                colors: ["#00CCFF", "#CCFF00"],
                pieHole: 0.5,
                chartArea: {
                 width: "100%",
                 height: "100%",
                 left: 0,
                 right: 0,
                 top: 0,
                 bottom: 0,
                },
                pieSliceText: "none",
                tooltip: { trigger: "none" },
               }}
              />
             </div>
             <div className="flex flex-col gap-1 opacity-0 group-hover/donut-card:opacity-100 transition-opacity">
              {donutData.slice(1).map((row: any, ri: number) => (
               <div key={ri} className="flex items-center justify-between px-2">
                <div className="flex items-center gap-2">
                 <div
                  className={`w-2 h-2 rounded-full ${ri === 0 ? "bg-[#00CCFF]" : "bg-[#CCFF00]"}`}
                 />
                 <span className="text-[10px] font-black text-black/40 uppercase">
                  {row[0]}
                 </span>
                </div>
                <span className="text-[10px] font-black">
                 {typeof row[1] === "number" ? row[1].toLocaleString() : row[1]}
                </span>
               </div>
              ))}
             </div>
            </div>
           )
          },
         )}
        </div>
       </div>
      : <div className="w-full h-full bg-white flex flex-col pt-2">
        <div
         className={`w-full ${isEngagementRanker ? "h-[calc(100%-52px)]" : "h-full"} relative`}>
         <MemoizedGoogleChart
          chartType={cfg.type as any}
          width="100%"
          height="100%"
          data={currentData}
          options={chartOptions}
          chartEvents={chartEvents as any}
         />
         {isEngagementRanker &&
          hovered?.row !== undefined &&
          Array.isArray(currentData) &&
          currentData.length > 2 && (
           <div
            className="absolute pointer-events-none bg-black/5 border-2 border-black z-10 transition-all duration-75"
            style={{
             top: 8,
             bottom: 8,
             width: `calc(100% / ${Math.max(1, (currentData as any[]).length - 1)})`,
             left: `calc((100% / ${Math.max(1, (currentData as any[]).length - 1)}) * ${hovered.row})`,
             transform: "translateX(-50%)",
            }}
           />
          )}
        </div>
        {isEngagementRanker && (
         <div className="h-[52px] flex items-center justify-center gap-8 px-4 border-t border-black/5 bg-gray-50/30">
          {[
           { label: "COMMENTS", color: "#00CCFF", metric: "Comments" },
           { label: "SUBSCRIBERS", color: "#CCFF00", metric: "Subscribers" },
           { label: "SHARES", color: "#FFDD00", metric: "Shares" },
           { label: "LIKES", color: "#FF7497", metric: "Likes" },
          ].map((s, idx) => (
           <button
            key={idx}
            onClick={() => setEngagementSortBy(s.metric)}
            className="flex items-center gap-2 group cursor-pointer">
            <div
             className="w-5 h-5 rounded-full border-2 border-black flex items-center justify-center transition-transform group-hover:scale-110 shadow-sm"
             style={{ backgroundColor: s.color }}>
             {engagementSortBy === s.metric && (
              <div className="w-2 bg-black h-2 rounded-full" />
             )}
            </div>
            <span
             className={`text-[11px] font-black uppercase tracking-widest ${engagementSortBy === s.metric ? "text-black" : "text-black/40"} group-hover:text-black transition-colors`}>
             {s.label}
            </span>
           </button>
          ))}
         </div>
        )}
       </div>
      }
     </div>
    }
   </div>
  </div>
 )
}
// --- GOOGLE CHARTS GALLERY COMPONENT ---
const GoogleChartsGallery: React.FC<{
 data: any[]
 allData?: any[]
 dataDateRange?: string
 filteredTrafficData?: any[]
 setActiveChart: (chart: any) => void
}> = ({
 data,
 allData = [],
 dataDateRange,
 filteredTrafficData = [],
 setActiveChart,
}) => {
 const [selectedChartIndex, setSelectedChartIndex] = useState<number | null>(
  null,
 )
 const [pieHoveredItem, setPieHoveredItem] = useState<Record<string, any>>({})
 const [selectedSoloVideoId, setSelectedSoloVideoId] = useState<string>("")

 const isDataEmpty = !data || data.length === 0

 const headers = isDataEmpty ? [] : Object.keys(data[0])
 const findKey = (keywords: string[]) =>
  headers.find((h) =>
   keywords.some((k) => h.toLowerCase().includes(k.toLowerCase())),
  ) || ""

 const titleKey =
  findKey(["video title", "title", "name"]) || (headers[0] ?? "")

 const videoOnlyData = useMemo(() => {
  if (isDataEmpty) return []
  return data.filter((row) => {
   const title = String(row[titleKey] || "").trim()
   if (!title) return false
   const lowerTitle = title.toLowerCase()
   // Exclude rows that are clearly totals or summaries
   if (
    (lowerTitle === "total" ||
     lowerTitle.startsWith("total:") ||
     lowerTitle.includes("summary")) &&
    row._userTag !== "single_long_video" &&
    row._userTag !== "single_short_video" &&
    row._userTag !== "geo" &&
    row._userTag !== "audience"
   ) {
    return false
   }
   return true
  })
 }, [data, titleKey])

 const viewsKey = findKey(["views"]) || "Views"
 const watchTimeKey = findKey(["watch time", "hours"]) || "Watch time (hours)"
 const ctrKey =
  findKey(["click-through rate", "ctr"]) || "Impressions click-through rate (%)"
 const impressionsKey = findKey(["impressions"]) || "Impressions"
 const subsKey = findKey(["subscribers"]) || "Subscribers"
 const likesKey = findKey(["likes"]) || "Likes"
 const commentsKey = findKey(["comments"]) || "Comments"
 const sharesKey = findKey(["shares"]) || "Shares"
 const avdKey =
  findKey(["average view duration", "avd"]) || "Average view duration"
 const apvKey =
  findKey(["percentage viewed", "apv"]) || "Average percentage viewed (%)"
 const stwKey =
  findKey(["stayed to watch", "stw"]) || "Stayed to watch at 0:30 (%)"
 const trafficSourceKey =
  findKey(["traffic source", "source"]) || "Traffic source"
 const externalSourceKey =
  findKey(["external site", "external"]) || "External site or app"
 const searchTermsKey =
  findKey(["search terms", "search term"]) || "YouTube search terms"
 const dateKey = findKey(["publish time", "date"]) || "Date"
 const revenueKey =
  findKey(["revenue", "earnings"]) || "Your estimated revenue (USD)"
 const durationKey = findKey(["duration"]) || "Duration"

 const canonicalFieldMap = useMemo(
  () => ({
   views: viewsKey,
   likes: likesKey,
   comments: commentsKey,
   shares: sharesKey,
   subscribersGained: subsKey,
   impressions: impressionsKey,
   ctr: ctrKey,
   estimatedRevenue: revenueKey,
   estimatedMinutesWatched: watchTimeKey,
   avgViewDurationSeconds: avdKey,
   videoLengthSeconds: durationKey,
   avgPercentageViewed: apvKey,
   stayedToWatchAt30: stwKey,
  }),
  [
   viewsKey,
   likesKey,
   commentsKey,
   sharesKey,
   subsKey,
   impressionsKey,
   ctrKey,
   revenueKey,
   watchTimeKey,
   avdKey,
   durationKey,
   apvKey,
   stwKey,
  ],
 )

 const availableCanonicalStats = useMemo(
  () =>
   collectAvailableCanonicalStats(
    videoOnlyData as Record<string, unknown>[],
    canonicalFieldMap,
   ),
  [videoOnlyData, canonicalFieldMap],
 )

 const resolveMissingMetrics = useCallback(
  (requiredMetrics?: string[]) => {
   if (!requiredMetrics || requiredMetrics.length === 0) return []
   return requiredMetrics.filter(
    (metric) => !availableCanonicalStats.has(metric as CanonicalStatKey),
   )
  },
  [availableCanonicalStats],
 )

 const parseDurationToSeconds = (duration: any) => {
  if (typeof duration === "number") return duration
  const d = String(duration || "").trim()
  if (!d) return 0
  const parts = d.split(":").map((p) => parseInt(p) || 0)
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2]
  if (parts.length === 2) return parts[0] * 60 + parts[1]
  return parseFloat(d) || 0
 }

 const lastThreeMonthsData = useMemo(() => {
  if (!videoOnlyData.length) return []
  const now = new Date()
  const threeMonthsAgo = new Date()
  threeMonthsAgo.setMonth(now.getMonth() - 3)

  const filtered = videoOnlyData.filter((r) => {
   const d = new Date(r[dateKey])
   return !isNaN(d.getTime()) && d >= threeMonthsAgo
  })
  return filtered.length > 0 ? filtered : videoOnlyData
 }, [videoOnlyData, dateKey])

 const viewsVsSubsOutliers = useMemo(() => {
  return videoOnlyData
   .filter((r) => {
    const views = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
    const subs = parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0
    return (views > 2500 || subs > 8) && subs > 0
   })
   .sort(
    (a, b) =>
     (parseFloat(String(b[viewsKey]).replace(/,/g, "")) || 0) -
     (parseFloat(String(a[viewsKey]).replace(/,/g, "")) || 0),
   )
   .slice(0, 5)
 }, [videoOnlyData, viewsKey, subsKey])

 const getTopN = (key: string, n = 10) =>
  [...videoOnlyData]
   .sort(
    (a, b) =>
     (parseFloat(String(b[key]).replace(/,/g, "")) || 0) -
     (parseFloat(String(a[key]).replace(/,/g, "")) || 0),
   )
   .slice(0, n)

 const aggregateStats = useMemo(() => {
  let views = 0,
   watchtime = 0,
   revenue = 0,
   subscribers = 0,
   impressions = 0

  videoOnlyData.forEach((r) => {
   views += parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
   watchtime += parseFloat(String(r[watchTimeKey]).replace(/,/g, "")) || 0
   revenue +=
    parseFloat(String(r[revenueKey] || "").replace(/[^0-9.-]+/g, "")) || 0
   subscribers += parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0
   impressions += parseFloat(String(r[impressionsKey]).replace(/,/g, "")) || 0
  })

  const rpm = views > 0 ? revenue / (views / 1000) : 0
  const ctr = impressions > 0 ? (views / impressions) * 100 : 0

  return {
   views: Math.round(views).toLocaleString(),
   watchtime: watchtime.toFixed(2),
   revenue: revenue.toFixed(2),
   subscribers: Math.round(subscribers).toLocaleString(),
   rpm: rpm.toFixed(2),
   ctr: ctr.toFixed(2) + "%",
  }
 }, [
  videoOnlyData,
  viewsKey,
  watchTimeKey,
  revenueKey,
  subsKey,
  impressionsKey,
 ])

 const { inRangeHonesty } = useMemo(() => {
  // Removed outOfRangeHonesty
  const shorts = videoOnlyData
   .filter((r) => r._userTag === "shorts")
   .sort(
    (a, b) => new Date(b[dateKey]).getTime() - new Date(a[dateKey]).getTime(),
   )
   .slice(0, 75)
  const longs = videoOnlyData
   .filter((r) => r._userTag === "long")
   .sort(
    (a, b) => new Date(b[dateKey]).getTime() - new Date(a[dateKey]).getTime(),
   )
   .slice(0, 75)

  const combined = [...shorts, ...longs]
  const inRange: any[] = []
  // const outOfRange: any[] = []; // Removed unused variable

  combined.forEach((r) => {
   const h = parseFloat(String(r[ctrKey]).replace(/,/g, "")) || 0
   const v = parseFloat(String(r[apvKey]).replace(/,/g, "")) || 0
   if (h > 0 && h <= 10 && v >= 0 && v <= 200) {
    inRange.push(r)
   } else {
    // outOfRange.push(r); // Removed unused variable
   }
  })
  return { inRangeHonesty: inRange /* , outOfRangeHonesty: outOfRange */ } // Removed outOfRangeHonesty
 }, [videoOnlyData, ctrKey, apvKey, dateKey])

 const [engagementSortBy, setEngagementSortBy] = useState<string>("Comments")
 // const [stackFilter, setStackFilter] = useState<"all" | "long" | "shorts">( // Removed unused variable
 //   "all",
 // );
 const [excludedOutliers, setExcludedOutliers] = useState<Set<string>>(
  new Set(),
 )

 const engagementData = useMemo(() => {
  if (!videoOnlyData.length) return []
  const keyMap: Record<string, string> = {
   Comments: commentsKey,
   Subscribers: subsKey,
   Shares: sharesKey,
   Likes: likesKey,
  }
  const sortKey = keyMap[engagementSortBy] || commentsKey

  const mostRecent50 = [...videoOnlyData]
   .sort(
    (a, b) => new Date(b[dateKey]).getTime() - new Date(a[dateKey]).getTime(),
   )
   .slice(0, 50)

  return mostRecent50.sort(
   (a, b) =>
    (parseFloat(String(b[sortKey]).replace(/,/g, "")) || 0) -
    (parseFloat(String(a[sortKey]).replace(/,/g, "")) || 0),
  )
 }, [
  videoOnlyData,
  engagementSortBy,
  commentsKey,
  subsKey,
  sharesKey,
  likesKey,
 ])

 // const channelStats = useMemo(() => { // Removed unused variable
 //   if (!videoOnlyData.length) return null;

 //   let totalViews = 0;
 //   let totalWatchTime = 0;
 //   let totalRevenue = 0;
 //   let totalSubs = 0;
 //   let totalImpressions = 0;

 //   videoOnlyData.forEach((r) => {
 //     totalViews += parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0;
 //     totalWatchTime +=
 //       parseFloat(String(r[watchTimeKey]).replace(/,/g, "")) || 0;
 //     totalRevenue += parseFloat(String(r[revenueKey]).replace(/,/g, "")) || 0;
 //     totalSubs += parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0;
 //     totalImpressions +=
 //       parseFloat(String(r[impressionsKey]).replace(/,/g, "")) || 0;
 //   });

 //   const avgCtr =
 //     totalImpressions > 0 ? (totalViews / totalImpressions) * 100 : 0;
 //   const rpm = totalViews > 0 ? totalRevenue / (totalViews / 1000) : 0;

 //   return {
 //     views: totalViews,
 //     watchTime: totalWatchTime,
 //     revenue: totalRevenue,
 //     subscribers: totalSubs,
 //     ctr: avgCtr,
 //     rpm: rpm,
 //   };
 // }, [
 //   videoOnlyData,
 //   viewsKey,
 //   watchTimeKey,
 //   revenueKey,
 //   subsKey,
 //   impressionsKey,
 // ]);

 const distributionData = useMemo(() => {
  if (!videoOnlyData.length) return null

  let sWT = 0,
   lWT = 0,
   sRev = 0,
   lRev = 0,
   sSubs = 0,
   lSubs = 0,
   sViews = 0,
   lViews = 0
  let sLikes = 0,
   lLikes = 0,
   sComm = 0,
   lComm = 0,
   sSh = 0,
   lSh = 0

  videoOnlyData.forEach((r) => {
   const isShort = r._userTag === "shorts"
   const wt = parseFloat(String(r[watchTimeKey]).replace(/,/g, "")) || 0
   const rev = parseFloat(String(r[revenueKey]).replace(/,/g, "")) || 0
   const subs = parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0
   const views = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
   const likes = parseFloat(String(r[likesKey]).replace(/,/g, "")) || 0
   const comm = parseFloat(String(r[commentsKey]).replace(/,/g, "")) || 0
   const sh = parseFloat(String(r[sharesKey]).replace(/,/g, "")) || 0

   if (isShort) {
    sWT += wt
    sRev += rev
    sSubs += subs
    sViews += views
    sLikes += likes
    sComm += comm
    sSh += sh
   } else {
    lWT += wt
    lRev += rev
    lSubs += subs
    lViews += views
    lLikes += likes
    lComm += comm
    lSh += sh
   }
  })

  const createDist = (s: number, l: number, u: string) => ({
   data: () => [
    ["Type", "Value"],
    ["Shorts", s],
    ["Long-form", l],
   ],
   shorts: s,
   long: l,
   unit: u,
  })

  return {
   views: createDist(sViews, lViews, "#"),
   watchTime: createDist(sWT, lWT, "h"),
   revenue: createDist(sRev, lRev, "$"),
   subscribers: createDist(sSubs, lSubs, "#"),
   likes: createDist(sLikes, lLikes, "#"),
   comments: createDist(sComm, lComm, "#"),
   shares: createDist(sSh, lSh, "#"),
  }
 }, [
  videoOnlyData,
  watchTimeKey,
  revenueKey,
  subsKey,
  viewsKey,
  likesKey,
  commentsKey,
  sharesKey,
 ])

 const keywordPerformance = useMemo(() => {
  if (!videoOnlyData.length) return []

  const stopWords = new Set([
   "the",
   "a",
   "an",
   "and",
   "or",
   "but",
   "in",
   "on",
   "at",
   "to",
   "for",
   "with",
   "by",
   "of",
   "is",
   "are",
   "was",
   "were",
   "be",
   "been",
   "being",
   "it",
   "its",
   "they",
   "them",
   "their",
   "this",
   "that",
   "these",
   "those",
   "i",
   "me",
   "my",
   "we",
   "us",
   "our",
   "you",
   "your",
   "he",
   "him",
   "his",
   "she",
   "her",
   "how",
   "what",
   "why",
   "where",
   "when",
   "who",
   "which",
   "can",
   "could",
   "will",
   "would",
   "should",
   "may",
   "might",
   "must",
   "do",
   "does",
   "did",
   "done",
   "doing",
   "has",
   "have",
   "had",
   "having",
   "not",
   "no",
   "yes",
   "so",
   "up",
   "down",
   "out",
   "off",
   "over",
   "under",
   "again",
   "further",
   "then",
   "once",
   "here",
   "there",
   "all",
   "any",
   "both",
   "each",
   "few",
   "more",
   "most",
   "other",
   "some",
   "such",
   "only",
   "own",
   "same",
   "than",
   "too",
   "very",
   "s",
   "t",
   "don",
   "just",
   "now",
   "d",
   "ll",
   "m",
   "o",
   "re",
   "ve",
   "y",
   "ain",
   "aren",
   "couldn",
   "didn",
   "doesn",
   "hadn",
   "hasn",
   "haven",
   "isn",
   "ma",
   "mightn",
   "mustn",
   "needn",
   "shan",
   "shouldn",
   "wasn",
   "weren",
   "won",
   "wouldn",
  ])

  const keywordMap: Record<
   string,
   {
    views: number[]
    retention: number[]
    subs: number[]
    likes: number[]
    avd: number[]
    count: number
   }
  > = {}

  videoOnlyData.forEach((r) => {
   const title = String(r[titleKey] || "")
   const words = title
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length > 2 && !stopWords.has(w))

   const views = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
   const retention = parseFloat(String(r[apvKey]).replace(/,/g, "")) || 0
   const subs = parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0
   const likes = parseFloat(String(r[likesKey]).replace(/,/g, "")) || 0
   const avd = parseDurationToSeconds(String(r[avdKey] || ""))

   const uniqueWords = new Set(words)
   uniqueWords.forEach((word) => {
    if (!keywordMap[word]) {
     keywordMap[word] = {
      views: [],
      retention: [],
      subs: [],
      likes: [],
      avd: [],
      count: 0,
     }
    }
    keywordMap[word].views.push(views)
    keywordMap[word].retention.push(retention)
    keywordMap[word].subs.push(subs)
    keywordMap[word].likes.push(likes)
    keywordMap[word].avd.push(avd)
    keywordMap[word].count += 1
   })
  })

  return Object.entries(keywordMap)
   .map(([keyword, stats]) => {
    const avgViews = stats.views.reduce((a, b) => a + b, 0) / stats.count
    const avgRetention =
     stats.retention.reduce((a, b) => a + b, 0) / stats.count
    const avgSubs = stats.subs.reduce((a, b) => a + b, 0) / stats.count
    const avgLikes = stats.likes.reduce((a, b) => a + b, 0) / stats.count
    const avgAvd = stats.avd.reduce((a, b) => a + b, 0) / stats.count

    // Efficiency Score: (AvgViews / MaxAvgViews * 40) + (AvgRetention / MaxAvgRetention * 30) + (AvgSubs / MaxAvgSubs * 30)
    const efficiencyScore = avgViews / 100 + avgRetention * 0.5 + avgSubs * 10

    return {
     keyword,
     avgViews,
     avgRetention,
     avgSubs,
     avgLikes,
     avgAvd,
     efficiencyScore,
     count: stats.count,
    }
   })
   .filter((k) => k.count >= 1)
   .sort((a, b) => b.avgAvd - a.avgAvd)
 }, [videoOnlyData, titleKey, viewsKey, apvKey, subsKey, likesKey, avdKey])

 const commonKeywords = useMemo(() => {
  return [...keywordPerformance].sort((a, b) => b.count - a.count).slice(0, 40)
 }, [keywordPerformance])

 const wordTreeData = useMemo(() => {
  if (!videoOnlyData.length || !commonKeywords.length) return [["Phrases"]]

  const commonSet = new Set(commonKeywords.map((k) => k.keyword.toLowerCase()))

  const titles = videoOnlyData
   .map((r) => {
    const title = String(r[titleKey] || "").toUpperCase()
    // Only keep words that are in the top 40 most common
    const words = title
     .split(/[^A-Z0-9]+/)
     .filter((w) => commonSet.has(w.toLowerCase()))
    return [words.join(" ")]
   })
   .filter((row) => row[0].length > 0)

  return [["Phrases"], ...titles]
 }, [videoOnlyData, titleKey, commonKeywords])

 const topKeyword = useMemo(() => {
  if (!commonKeywords.length) return ""
  // Use the most common keyword as the root
  return commonKeywords[0].keyword.toUpperCase()
 }, [commonKeywords])

 const totalWordCount = useMemo(() => {
  return videoOnlyData.reduce((acc, r) => {
   const title = String(r[titleKey] || "")
   return acc + title.split(/\s+/).filter((w) => w.length > 0).length
  }, 0)
 }, [videoOnlyData, titleKey])

 const headerColors = [...RESEARCH_LAB_HEADER_COLORS]
 const topPerformersSpec = getChartSpecById("top-performers-trio")
 const shortsRetentionSpec = getChartSpecById("shorts-retention")
 const packagingSpec = getChartSpecById("packaging")
 const engagementMapSpec = getChartSpecById("engagement-map")
 const keywordEngineSpec = getChartSpecById("keyword-engine")
 const performanceStackSpec = getChartSpecById("performance-stack")
 const valueMatrixSpec = getChartSpecById("video-value-matrix")

 const chartConfigs = useMemo(() => {
  const configs = [
   {
    title: topPerformersSpec.title,
    subtitle: topPerformersSpec.subtitle,
    type: topPerformersSpec.chartType,
    provider: "google",
    data: () => {
     // Individual Performers
     const top10Revenue = [...lastThreeMonthsData]
      .sort(
       (a, b) =>
        (parseFloat(String(a[revenueKey]).replace(/[^0-9.-]+/g, "")) || 0) -
        (parseFloat(String(b[revenueKey]).replace(/[^0-9.-]+/g, "")) || 0),
      )
      .slice(0, 10)
     let mmData = [["Video", "Revenue"]]
     if (top10Revenue.length) {
      mmData = [
       ...mmData,
       ...top10Revenue.map((r) => {
        const val =
         parseFloat(String(r[revenueKey]).replace(/[^0-9.-]+/g, "")) || 0
        return [
         String(r[titleKey]).toUpperCase(),
         { v: val, f: `$${val.toFixed(2)}` },
        ]
       }),
      ] as any
     } else {
      mmData.push(["No Data", 0] as any)
     }

     const topWatchTime = getTopN(watchTimeKey)
     let mwData = [["Video", "Watch Time"]]
     if (topWatchTime.length) {
      mwData = [
       ...mwData,
       ...topWatchTime.map((r) => [
        String(r[titleKey]).toUpperCase(),
        Math.round(parseFloat(String(r[watchTimeKey]).replace(/,/g, "")) || 0),
       ]),
      ] as any
     } else {
      mwData.push(["No Data", 0] as any)
     }

     const topSubs = getTopN(subsKey)
     let nsData = [["Video", "Subscribers"]]
     if (topSubs.length) {
      nsData = [
       ...nsData,
       ...topSubs.map((r) => [
        String(r[titleKey]).toUpperCase(),
        parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0,
       ]),
      ] as any
     } else {
      nsData.push(["No Data", 0] as any)
     }

     // Trends
     if (!distributionData)
      return { moneyMakers: mmData, mostViewed: mwData, newSubs: nsData }
     return {
      moneyMakers: mmData,
      mostViewed: mwData,
      newSubs: nsData,
      trends: [
       { label: "VIEWS", data: distributionData.views.data() },
       { label: "WATCH TIME", data: distributionData.watchTime.data() },
       { label: "REVENUE", data: distributionData.revenue.data() },
       { label: "NEW SUBS", data: distributionData.subscribers.data() },
      ],
     }
    },
    options: {},
   },

   {
    title: shortsRetentionSpec.title,
    subtitle: shortsRetentionSpec.subtitle,
    tier: "B",
    requiredMetrics: ["watch_time_per_video_minute"],
    insight: {
     title: "Shorts Ceiling",
     statPair: "Length x APV",
     reveal: "Shows where short-form length starts to reduce retention.",
    },
    type: "ScatterChart",
    provider: "google",
    data: () => {
     const header = [
      "Duration (Seconds)",
      "Avg % Viewed",
      { role: "style" },
      { role: "tooltip", type: "string" },
     ]
     const shortsData = [...videoOnlyData]
      .filter((r) => {
       const apv = parseFloat(String(r[apvKey]).replace(/,/g, "")) || 0
       return r._userTag === "shorts" && apv > 0
      })
      .sort(
       (a, b) =>
        new Date(b[dateKey]).getTime() - new Date(a[dateKey]).getTime(),
      )
      .slice(0, 250)

     if (!shortsData.length)
      return [header, [0, 0, "point { fill-color: #000; }", "No Shorts Data"]]

     return [
      header,
      ...shortsData.map((r) => {
       const durSec = parseDurationToSeconds(r[durationKey])
       const apv = parseFloat(String(r[apvKey]).replace(/,/g, "")) || 0
       const color =
        durSec < 60 ? "#FF6321"
        : durSec < 120 ? "#00CCFF"
        : "#00FF00"
       const style = `point { fill-color: ${color}; size: 5; opacity: 0.6; }`
       const title = String(r[titleKey]).toUpperCase()
       return [
        durSec,
        apv,
        style,
        `${title}\nDURATION: ${durSec}s\nAPV: ${apv}%`,
       ]
      }),
     ]
    },
    options: {
     chartArea: {
      left: 50,
      right: 20,
      top: 20,
      bottom: 40,
      width: "90%",
      height: "70%",
      backgroundColor: "transparent",
     },
     hAxis: {
      title: "DURATION (SECONDS)",
      ticks: [30, 60, 90, 120, 150, 180],
      viewWindow: { min: 0, max: 180 },
      baselineColor: "#000",
     },
     vAxis: {
      title: "AVG % VIEWED",
      viewWindow: { min: 0, max: 100 },
      baselineColor: "#000",
      ticks: [20, 40, 60, 80, 100],
     },
     legend: { position: "none" },
    },
   },
   {
    title: packagingSpec.title,
    subtitle: packagingSpec.subtitle,
    tier: "B",
    requiredMetrics: ["ctr_percent", "impressions"],
    insight: {
     title: "Packaging Signal",
     statPair: "CTR x Impressions",
     reveal: "Shows how strong packaging performs as distribution expands.",
    },
    type: "BubbleChart",
    data: () => {
     const header = [
      "ID",
      "Impressions",
      "CTR",
      "Type",
      "Views",
      { role: "tooltip", type: "string" },
     ]
     const topVideos = getTopN(viewsKey, 20)
     if (!topVideos.length) return [header, ["", 0, 0, "Video", 0, "No Data"]]
     return [
      header,
      ...topVideos.map((r) => [
       "",
       parseFloat(String(r[impressionsKey]).replace(/,/g, "")) || 0,
       parseFloat(String(r[ctrKey]).replace(/,/g, "")) || 0,
       r._userTag === "shorts" ? "Shorts" : "Long-form",
       parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0,
       `${String(r[titleKey]).toUpperCase()}\nIMPRESSIONS: ${r[impressionsKey]}\nCTR: ${r[ctrKey]}%`,
      ]),
     ]
    },
    options: {
     backgroundColor: "transparent",
     hAxis: {
      title: "IMPRESSIONS",
      format: "short",
      baselineColor: "#000",
      ticks: [0, 10000, 20000, 30000, 40000],
     },
     vAxis: {
      title: "CTR %",
      format: "short",
      baselineColor: "#000",
      ticks: [2, 4, 6, 8, 10, 12],
     },
     series: {
      Shorts: { color: "#FF7497" },
      "Long-form": { color: "#00CCFF" },
     },
     bubble: { textStyle: { fontSize: 0 } },
    },
   },
   {
    title: engagementMapSpec.title,
    subtitle: `Top 50 Recent by ${engagementSortBy}`,
    type: "LineChart",
    isEngagementRanker: true,
    provider: "google",
    data: () => {
     const header = ["Video", ...engagementMetrics]
     if (!engagementData.length) return [header, ["No Data", 0, 0, 0, 0]]
     const rows = engagementData.map((r) => {
      const row: any[] = [String(r[titleKey]).toUpperCase()]
      engagementMetrics.forEach((m) => {
       const k =
        m === "Comments" ? commentsKey
        : m === "Subscribers" ? subsKey
        : m === "Shares" ? sharesKey
        : likesKey
       row.push(parseFloat(String(r[k]).replace(/,/g, "")) || 0)
      })
      return row
     })
     return [header, ...rows]
    },
    options: {
     backgroundColor: "transparent",
     vAxes: {
      0: {
       title: "ENGAGEMENT METRICS",
       ticks: [0, 4, 8, 12, 16, 20, 24],
       viewWindow: { min: 0, max: 24 },
       baselineColor: "#000",
      },
      1: {
       title: "LIKES",
       ticks: [0, 50, 100, 150, 200, 250, 300],
       viewWindow: { min: 0, max: 300 },
       baselineColor: "#000",
      },
     },
     hAxis: {
      title: "VIDEOS (SORTED)",
      format: "MMM d",
      textPosition: "none",
      baseline: 0,
      baselineColor: "#000",
     },
     series: {
      0: { targetAxisIndex: 0 },
      1: { targetAxisIndex: 0 },
      2: { targetAxisIndex: 0 },
      3: { targetAxisIndex: 1 },
     },
     curveType: "function",
     lineWidth: 3,
     pointsVisible: false,
     crosshair: {
      trigger: "both",
      orientation: "vertical",
      color: "#000",
      opacity: 0.1,
     },
     tooltip: { trigger: "none" },
     focusTarget: "category",
     legend: { position: "none" },
     colors: engagementMetrics.map((m) => metricColors[m]),
    },
   },

   {
    title: keywordEngineSpec.title,
    subtitle: keywordEngineSpec.subtitle,
    type: "BarChart",
    data: () => {
     const header = [
      "Keyword",
      "Avg Views",
      { role: "style" },
      { role: "tooltip", type: "string" },
     ]
     const top20 = [...keywordPerformance]
      .filter((k) => k.count >= 2)
      .sort((a, b) => b.avgViews - a.avgViews)
      .slice(0, 20)
     if (!top20.length) return [header, ["No Data", 0, "color:#000", "No Data"]]
     const maxViews = top20[0].avgViews

     return [
      header,
      ...top20.map((k) => {
       const opacity = 0.3 + (k.avgViews / maxViews) * 0.7
       const style = `color: #00CCFF; fill-opacity: ${opacity}; stroke-width: 2; stroke-color: #000`
       const label = k.keyword.toUpperCase()
       return [
        label,
        k.avgViews,
        style,
        `${label}\nAVG VIEWS: ${Math.round(k.avgViews).toLocaleString()}\nUSED IN: ${k.count} VIDEOS`,
       ]
      }),
     ]
    },
    options: {
     backgroundColor: "transparent",
     chartArea: {
      left: 140,
      right: 30,
      top: 20,
      bottom: 40,
      width: "80%",
      height: "85%",
     },
     hAxis: {
      title: "AVG VIEWS PER VIDEO USING THIS WORD",
      format: "short",
      baselineColor: "#000",
     },
     vAxis: { title: "", textStyle: { fontSize: 11 } },
     legend: { position: "none" },
     bar: { groupWidth: "75%" },
    },
   },

   {
    title: performanceStackSpec.title,
    subtitle: performanceStackSpec.subtitle,
    tier: "A",
    requiredMetrics: ["retention_30_percent_viewers", "ctr_percent", "views"],
    insight: {
     title: "Hook Integrity",
     statPair: "30s Retention x CTR",
     reveal: "Separates strong hooks from weak hooks using only raw retention.",
    },
    type: "SteppedAreaChart",
    provider: "google",
    data: () => {
     const header = [
      "Video",
      "Other (Down)",
      "CTR Anchor",
      "Stayed to Watch (Up)",
     ]
     // Safe access: if data is missing, return header with placeholder
     if (!videoOnlyData || videoOnlyData.length === 0)
      return [header, ["WAITING", 0, 0, 0]]

     return [
      header,
      ...videoOnlyData.slice(0, 10).map((v) => {
       const title = String(v?.[titleKey] || v?.title || "Video")
        .substring(0, 15)
        .toUpperCase()
       const retention =
        Math.max(0, parseFloat(String(v?.[stwKey] || 0).replace(/,/g, ""))) || 0
       const ctr = Math.max(
        0,
        parseFloat(String(v?.[ctrKey] || v?.ctr || 0).replace(/,/g, "")) || 0,
       )
       const views =
        Math.max(
         0,
         parseFloat(String(v?.[viewsKey] || v?.views || 0).replace(/,/g, "")) ||
          0,
        ) / 1000

       return [
        title,
        -views, // Flows DOWN
        ctr,
        retention, // Flows UP
       ]
      }),
     ]
    },
    options: {
     isStacked: true,
     backgroundColor: "transparent",
     chartArea: { width: "95%", height: "85%" },
     vAxis: {
      baseline: 0,
      textPosition: "none",
      gridlines: { count: 0 },
      baselineColor: "#555",
     },
     hAxis: {
      textPosition: "none",
      gridlines: { color: "transparent" },
      baselineColor: "transparent",
     },
     legend: { position: "none" },
     colors: ["#6366F1", "#10B981", "#4F46E5"], // Purple (Down), Green (Anchor), Indigo (Up)
     tooltip: { isHtml: false },
    },
   },

   {
    title: "Viewer Loyalty",
    subtitle: "New vs Returning Viewers",
    tier: "A",
    requiredMetrics: ["views"],
    insight: {
     title: "Loyalty Split",
     statPair: "New x Returning",
     reveal:
      "Shows whether videos attract fresh viewers or bring audiences back.",
    },
    type: "BubbleChart",
    provider: "google",
    data: () => {
     const newKey = findKey(["new viewer", "new viewers"])
     const retKey = findKey(["returning viewer", "returning viewers"])
     const header = [
      "ID",
      "New Viewers",
      "Returning Viewers",
      "Type",
      "Views",
      { role: "tooltip", type: "string" },
     ]

     // Filter out excluded outliers
     const validVideos = videoOnlyData.filter(
      (v) => !excludedOutliers.has(v._id),
     )

     if (!newKey || !retKey)
      return [header, ["", 0, 0, "No Data", 0, "No Data"]]
     const filtered = validVideos
      .filter((r) => {
       const n = parseFloat(String(r[newKey]).replace(/,/g, "")) || 0
       const ret = parseFloat(String(r[retKey]).replace(/,/g, "")) || 0
       return n > 0 || ret > 0
      })
      .sort(
       (a, b) =>
        new Date(b[dateKey]).getTime() - new Date(a[dateKey]).getTime(),
      )
      .slice(0, 40)
     if (!filtered.length) return [header, ["", 0, 0, "No Data", 0, "No Data"]]
     return [
      header,
      ...filtered.map((r) => {
       const n = parseFloat(String(r[newKey]).replace(/,/g, "")) || 0
       const ret = parseFloat(String(r[retKey]).replace(/,/g, "")) || 0
       const t = String(r[titleKey]).toUpperCase()
       return [
        r._id || "",
        n,
        ret,
        r._userTag === "shorts" ? "Shorts" : "Long-form",
        parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0,
        `${t}\nNEW: ${n.toLocaleString()}\nRETURNING: ${ret.toLocaleString()}\n\n[TRIPLE CLICK TO REMOVE OUTLIER]`,
       ]
      }),
     ]
    },
    options: {
     chartArea: {
      left: 80,
      right: 20,
      top: 20,
      bottom: 50,
      backgroundColor: "transparent",
     },
     hAxis: {
      title: "NEW VIEWERS",
      format: "short",
      baselineColor: "#000",
      viewWindow: { min: 0 },
     },
     vAxis: {
      title: "RETURNING VIEWERS",
      format: "short",
      baselineColor: "#000",
      viewWindow: { min: 0 },
     },
     series: {
      "Long-form": { color: "#00CCFF" },
      Shorts: { color: "#FF7497" },
     },
     colors: ["#00CCFF", "#FF7497"],
     bubble: { textStyle: { fontSize: 0 }, opacity: 0.75 },
     sizeAxis: { minSize: 10, maxSize: 40 },
     legend: { position: "none" },
     tooltip: { trigger: "focus" },
    },
   },

   {
    title: "Title Stats",
    subtitle: "CTR x Keywords",
    type: "ScatterChart",
    data: () => {
     const getFiltered = (tag: string) => {
      return [...videoOnlyData]
       .filter((r) => {
        const ctr = parseFloat(String(r[ctrKey]).replace(/,/g, "")) || 0
        return r._userTag === tag && ctr > 0
       })
       .sort(
        (a, b) =>
         (parseFloat(String(b[viewsKey]).replace(/,/g, "")) || 0) -
         (parseFloat(String(a[viewsKey]).replace(/,/g, "")) || 0),
       )
       .slice(0, 50)
     }

     const longVideos = getFiltered("long")
     const shortsVideos = getFiltered("shorts")

     const combined = [...longVideos, ...shortsVideos]
     const header = [
      "Title Length",
      "CTR %",
      { role: "style" },
      { role: "tooltip", type: "string" },
     ]

     if (!combined.length)
      return [header, [0, 0, "point { fill-color: #000; }", "No Data"]]

     return [
      header,
      ...combined.map((r) => {
       const title = String(r[titleKey] || "")
       const ctr = parseFloat(String(r[ctrKey]).replace(/,/g, "")) || 0
       const isShort = r._userTag === "shorts"
       const color = isShort ? "#FF7497" : "#00CCFF"
       const style = `point { fill-color: ${color}; size: ${isShort ? 4 : 6}; }`
       return [
        title.length,
        ctr,
        style,
        `${title.toUpperCase()}\nLENGTH: ${title.length}\nCTR: ${ctr}%`,
       ]
      }),
     ]
    },
    options: {
     chartArea: {
      left: 50,
      right: 20,
      top: 20,
      bottom: 40,
      width: "90%",
      height: "70%",
      backgroundColor: "transparent",
     },
     hAxis: {
      title: "TITLE LENGTH (CHARS)",
      viewWindow: { min: 0, max: 100 },
      gridlines: { color: "#f0f0f0" },
      baselineColor: "#000",
      ticks: [0, 20, 40, 60, 80, 100],
     },
     vAxis: {
      title: "CTR %",
      viewWindow: { min: 0, max: 20 },
      gridlines: { color: "#f0f0f0" },
      baselineColor: "#000",
      ticks: [5, 10, 15, 20],
     },
     legend: "none",
    },
   },

   {
    title: "Audience Geography",
    subtitle: "Views x Global Reach",
    type: "GeographySplitView",
    provider: "google",
    data: () => {
     const header = ["Country", "Views"]
     const countryMap: Record<string, number> = {}
     ;(allData || []).forEach((r) => {
      if (!r) return
      const cKey = Object.keys(r || {}).find((k) => {
       const l = k.toLowerCase()
       return (
        l.includes("geo") ||
        l.includes("country") ||
        l.includes("region") ||
        l.includes("location")
       )
      })
      const vKey = Object.keys(r || {}).find((k) =>
       k.toLowerCase().includes("view"),
      )
      if (cKey && vKey) {
       const countryVal = String(r[cKey] || "").trim()
       const viewsVal = String(r[vKey] || "").trim()
       if (
        countryVal &&
        countryVal !== "Total" &&
        !countryVal.includes("---")
       ) {
        if (countryVal.includes(",")) {
         const countries = countryVal.split(",")
         const values = viewsVal.split(",")
         countries.forEach((country, i) => {
          const clean = country
           .trim()
           .toUpperCase()
           .replace(/^TOTAL$|^Total$/, "")
          const val =
           parseFloat(
            String(values[i] || "0")
             .trim()
             .replace(/,/g, ""),
           ) || 0
          if (clean && clean.length <= 32) {
           countryMap[clean] = (countryMap[clean] || 0) + val
          }
         })
        } else {
         const finalKey =
          countryVal.length === 2 ? countryVal.toUpperCase() : countryVal
         const val = parseFloat(viewsVal.replace(/,/g, "")) || 0
         if (finalKey && val > 0) {
          countryMap[finalKey] = (countryMap[finalKey] || 0) + val
         }
        }
       }
      }
     })
     const finalRows = Object.entries(countryMap).sort((a, b) => b[1] - a[1])
     return finalRows.length > 0 ?
       [header, ...finalRows]
      : [header, ["US", 1], ["GB", 0]]
    },
    options: {
     colorAxis: {
      colors: ["#00CCFF", "#CCFF00", "#FFDD00", "#FFB158", "#FF7497"],
     },
     backgroundColor: "transparent",
     datalessRegionColor: "#f5f5f5",
     // Enlarge map
     chartArea: { width: "110%", height: "110%", top: "-5%", bottom: "-5%" },
    },
   },

   {
    title: "Hook-to-Binge Funnel",
    subtitle: "Views → Watch → Subs → Shares",
    tier: "A",
    requiredMetrics: ["views", "retention_30_percent_viewers", "impressions"],
    insight: {
     title: "Hook-to-Binge",
     statPair: "Impressions x Retention30",
     reveal:
      "Tracks how many viewers remain after hook without synthetic fallback.",
    },
    type: "Sankey",
    provider: "google",
    data: () => {
     const header = ["From", "To", "Weight"]
     let totalViews = 0,
      totalWatchedPast30 = 0,
      totalFinished = 0,
      totalSubs = 0,
      totalLikes = 0,
      totalShares = 0,
      totalComments = 0
     videoOnlyData.forEach((r) => {
      const views = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
      const stw = parseFloat(String(r[stwKey]).replace(/,/g, "")) || 0
      const apv = parseFloat(String(r[apvKey]).replace(/,/g, "")) || 0
      const subs = parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0
      const likes = parseFloat(String(r[likesKey]).replace(/,/g, "")) || 0
      const shares = parseFloat(String(r[sharesKey]).replace(/,/g, "")) || 0
      const comments = parseFloat(String(r[commentsKey]).replace(/,/g, "")) || 0
      totalViews += views
      totalWatchedPast30 += stw > 0 ? views * (stw / 100) : 0
      totalFinished += apv > 0 ? views * Math.min(apv / 100, 1) * 0.3 : 0
      totalSubs += subs
      totalLikes += likes
      totalShares += shares
      totalComments += comments
     })
     if (totalViews === 0) return [header, ["No Data", "No Output", 1]]
     const hooked = Math.round(totalWatchedPast30)
     const finished = Math.round(totalFinished)
     const engaged = totalSubs + totalLikes + totalShares + totalComments
     const impressions = videoOnlyData.reduce((sum, row) => {
      return (
       sum +
       (parseFloat(String(row[impressionsKey] || "0").replace(/,/g, "")) || 0)
      )
     }, 0)
     const estImpressions = impressions
     return [
      header,
      ["1. IMPRESSIONS", "2. VIEWS", totalViews],
      [
       "1. IMPRESSIONS",
       "SCROLLED PAST",
       Math.max(0, estImpressions - totalViews),
      ],
      ["2. VIEWS", "3. HOOKED (>30s)", hooked],
      ["2. VIEWS", "DROPPED EARLY", Math.max(0, totalViews - hooked)],
      ["3. HOOKED (>30s)", "4. FINISHED", finished],
      ["3. HOOKED (>30s)", "PARTIAL WATCH", Math.max(0, hooked - finished)],
      ["4. FINISHED", "5. ENGAGED", engaged],
      ["4. FINISHED", "PASSIVE", Math.max(0, finished - engaged)],
     ]
    },
    options: {
     sankey: {
      node: {
       colors: [
        "#00CCFF",
        "#CCFF00",
        "#FF7497",
        "#FFDD00",
        "#FFB158",
        "#B14AED",
        "#00FF9D",
        "#FF6321",
        "#FF87F3",
       ],
       label: { fontName: "Inter", fontSize: 13, bold: true, color: "#000" },
       nodePadding: 20,
      },
      link: { colorMode: "source", fillOpacity: 0.2 },
      iterations: 0,
     },
     chartArea: {
      left: 10,
      right: 10,
      top: 10,
      bottom: 10,
      width: "98%",
      height: "95%",
     },
     legend: { position: "none" },
    },
   },

   {
    title: "Best Upload Day",
    subtitle: "Weekday × Avg Views",
    type: "ColumnChart",
    data: () => {
     const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
     const groups: Record<
      number,
      { views: number[]; ctr: number[]; subs: number[] }
     > = {}
     DAYS.forEach((_, idx) => {
      groups[idx] = { views: [], ctr: [], subs: [] }
     })
     videoOnlyData.forEach((r) => {
      const d = new Date(r[dateKey])
      if (isNaN(d.getTime())) return
      const day = d.getDay()
      const v = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
      const c = parseFloat(String(r[ctrKey]).replace(/,/g, "")) || 0
      const s = parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0
      if (v > 0) groups[day].views.push(v)
      if (c > 0) groups[day].ctr.push(c)
      if (s > 0) groups[day].subs.push(s)
     })
     const avg = (arr: number[]) =>
      arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0
     const maxViews = Math.max(...DAYS.map((_, idx) => avg(groups[idx].views)))
     const header = [
      "Day",
      "Avg Views",
      { role: "style" },
      { role: "tooltip", type: "string" },
     ]
     const rows = DAYS.map((day, idx) => {
      const avgViews = avg(groups[idx].views)
      const avgCtr = avg(groups[idx].ctr)
      const avgSubs = avg(groups[idx].subs)
      const ratio = avgViews / (maxViews || 1)
      const r2 = Math.round(255 * (1 - ratio))
      const g2 = Math.round(200 * ratio)
      return [
       day,
       Math.round(avgViews),
       `color: rgb(${r2}, ${g2}, 50)`,
       `${day.toUpperCase()}\nAVG VIEWS: ${Math.round(avgViews).toLocaleString()}\nAVG CTR: ${avgCtr.toFixed(1)}%\nAVG SUBS: ${avgSubs.toFixed(1)}\nVIDEOS: ${groups[idx].views.length}`,
      ]
     })
     if (rows.every((r) => r[1] === 0))
      return [header, ["No Data", 0, "color:#000", "No Data"]]
     return [header, ...rows]
    },
    options: {
     chartArea: {
      left: 50,
      right: 20,
      top: 10,
      bottom: 40,
      backgroundColor: "transparent",
     },
     hAxis: { title: "DAY OF WEEK", baselineColor: "#000" },
     vAxis: {
      title: "AVG VIEWS",
      format: "short",
      baselineColor: "#000",
      viewWindow: { min: 0 },
     },
     legend: { position: "none" },
     bar: { groupWidth: "70%" },
    },
   },

   {
    title: "Duration Sweet Spot",
    subtitle: "Video Length × Avg Views",
    type: "BarChart",
    data: () => {
     const buckets: Record<string, { views: number[]; ctr: number[] }> = {
      "0–1 min": { views: [], ctr: [] },
      "1–3 min": { views: [], ctr: [] },
      "3–5 min": { views: [], ctr: [] },
      "5–8 min": { views: [], ctr: [] },
      "8–12 min": { views: [], ctr: [] },
      "12–20 min": { views: [], ctr: [] },
      "20–30 min": { views: [], ctr: [] },
      "30+ min": { views: [], ctr: [] },
     }
     const getBucket = (sec: number) => {
      if (sec < 60) return "0–1 min"
      if (sec < 180) return "1–3 min"
      if (sec < 300) return "3–5 min"
      if (sec < 480) return "5–8 min"
      if (sec < 720) return "8–12 min"
      if (sec < 1200) return "12–20 min"
      if (sec < 1800) return "20–30 min"
      return "30+ min"
     }
     videoOnlyData.forEach((r) => {
      const sec = parseDurationToSeconds(r[durationKey])
      if (sec <= 0) return
      const v = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
      const c = parseFloat(String(r[ctrKey]).replace(/,/g, "")) || 0
      const bucket = getBucket(sec)
      if (v > 0) buckets[bucket].views.push(v)
      if (c > 0) buckets[bucket].ctr.push(c)
     })
     const avg = (arr: number[]) =>
      arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0
     const maxV = Math.max(...Object.values(buckets).map((b) => avg(b.views)))
     const header = [
      "Duration",
      "Avg Views",
      { role: "style" },
      { role: "tooltip", type: "string" },
     ]
     const rows = Object.entries(buckets)
      .map(([label, b]) => {
       const avgV = avg(b.views),
        avgC = avg(b.ctr)
       const ratio = avgV / (maxV || 1)
       const r2 = Math.round(255 * (1 - ratio))
       const g2 = Math.round(200 * ratio)
       return [
        label,
        Math.round(avgV),
        `color: rgb(${r2}, ${g2}, 50)`,
        `${label}\nAVG VIEWS: ${Math.round(avgV).toLocaleString()}\nAVG CTR: ${avgC.toFixed(1)}%\nVIDEOS: ${b.views.length}`,
       ]
      })
      .filter((r) => (r[1] as number) > 0)
     if (!rows.length) return [header, ["No Data", 0, "color:#000", "No Data"]]
     return [header, ...rows]
    },
    options: {
     chartArea: {
      left: 80,
      right: 20,
      top: 10,
      bottom: 40,
      backgroundColor: "transparent",
     },
     hAxis: { title: "AVG VIEWS", format: "short", baselineColor: "#000" },
     vAxis: { title: "", textStyle: { fontSize: 11 } },
     legend: { position: "none" },
     bar: { groupWidth: "75%" },
    },
   },

   {
    title: valueMatrixSpec.title,
    subtitle: "CTR x Retention x Views",
    type: "BubbleChart",
    provider: "google",
    data: () => {
     // Cols: ID (empty string = no label), X=CTR, Y=Retention, Color/Series, Size=Views, Tooltip
     const header = [
      "",
      "CTR %",
      "Retention %",
      "Type",
      "Views",
      { role: "tooltip", type: "string" },
     ]
     if (!inRangeHonesty.length)
      return [header, ["", 0, 0, "No Data", 0, "No Data"]]
     return [
      header,
      ...inRangeHonesty.map((r) => {
       const ctr = parseFloat(String(r[ctrKey]).replace(/,/g, "")) || 0
       const apv = parseFloat(String(r[apvKey]).replace(/,/g, "")) || 0
       const views = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
       const title = String(r[titleKey] || "Untitled")
       const isShort = r._userTag === "shorts"
       const tooltip = `${title.toUpperCase()}\nCTR: ${ctr.toFixed(1)}%  RETENTION: ${apv.toFixed(0)}%\nVIEWS: ${views.toLocaleString()}\nTYPE: ${isShort ? "SHORTS" : "LONG-FORM"}`
       return ["", ctr, apv, isShort ? "Shorts" : "Long-form", views, tooltip]
      }),
     ]
    },
    options: {
     chartArea: {
      left: 55,
      right: 20,
      top: 20,
      bottom: 45,
      backgroundColor: {
       stroke: "#000",
       strokeWidth: 1.5,
       fill: "transparent",
      },
     },
     hAxis: {
      title: "CTR %",
      gridlines: { color: "#f3f3f3" },
      baseline: 5,
      baselineColor: "#000",
      viewWindow: { min: 0, max: 10 },
      ticks: [0, 2, 4, 6, 8, 10],
     },
     vAxis: {
      title: "RETENTION %",
      gridlines: { color: "#f3f3f3" },
      baseline: 60,
      baselineColor: "#000",
      viewWindow: { min: 0, max: 150 },
      ticks: [25, 50, 75, 100, 125, 150],
     },
     series: {
      Shorts: { color: "#FF7497" },
      "Long-form": { color: "#00CCFF" },
     },
     colors: ["#00CCFF", "#FF7497"],
     bubble: {
      textStyle: { fontSize: 1, color: "transparent", auraColor: "none" },
      opacity: 0.75,
     },
     sizeAxis: { minSize: 4, maxSize: 30 },
     legend: { position: "none" },
     tooltip: { trigger: "none" },
    },
   },

   {
    title: "Revenue Calendar",
    subtitle: "Top 5 Days Per Month",
    type: "Calendar",
    data: () => {
     const header = [{ type: "date", label: "Date" }, "Revenue ($)"]
     const byDate: Record<string, number> = {}
     videoOnlyData.forEach((r) => {
      const d = new Date(r[dateKey])
      if (isNaN(d.getTime())) return
      const key = d.toISOString().slice(0, 10)
      const rev =
       parseFloat(String(r[revenueKey] || "").replace(/[^0-9.-]+/g, "")) || 0
      if (!byDate[key]) byDate[key] = 0
      byDate[key] += rev
     })

     const byMonth: Record<string, { dateStr: string; rev: number }[]> = {}
     Object.entries(byDate).forEach(([dateStr, rev]) => {
      const month = dateStr.slice(0, 7)
      if (!byMonth[month]) byMonth[month] = []
      byMonth[month].push({ dateStr, rev })
     })

     const rows: any[] = []
     Object.values(byMonth).forEach((days) => {
      days.sort((a, b) => b.rev - a.rev)
      const top5 = days.slice(0, 5)
      top5.forEach((day, i) => {
       const rank = 5 - i // 5 for best, 1 for 5th best
       rows.push([
        new Date(day.dateStr),
        { v: rank, f: "$" + day.rev.toFixed(2) },
       ])
      })
     })

     if (!rows.length) return [header, [new Date(), 0]]
     return [header, ...rows]
    },
    options: {
     title: "",
     calendar: {
      cellSize: 16,
      cellColor: { stroke: "#f0f0f0", strokeOpacity: 0.5, strokeWidth: 1 },
      monthLabel: {
       fontName: "Inter",
       fontSize: 13,
       bold: true,
       color: "#000",
      },
      dayOfWeekLabel: { fontName: "Inter", fontSize: 11, color: "#666" },
      monthOutlineColor: {
       stroke: "#000",
       strokeOpacity: 0.3,
       strokeWidth: 1,
      },
     },
     colorAxis: {
      minValue: 1,
      maxValue: 5,
      colors: [
       "#D1D5DB", // 1 (5th best): Light Grey
       "#9CA3AF", // 2 (4th best): Darker Grey
       "#6EE7B7", // 3 (3rd best): Pastel Emerald
       "#10B981", // 4 (2nd best): Emerald
       "#059669", // 5 (1st best): Vivid Deep Emerald
      ],
     },
     noDataPattern: { backgroundColor: "#f9f9f9", color: "#e0e0e0" },
     legend: { position: "none" },
    },
   },

   {
    title: "Milestone Progression",
    subtitle: "Cumulative Views",
    type: "SteppedAreaChart",
    provider: "google",
    data: () => {
     const sorted = [...videoOnlyData].sort(
      (a, b) => new Date(a[dateKey]).getTime() - new Date(b[dateKey]).getTime(),
     )
     const header = ["Date", "Cumulative Views"]
     let total = 0
     return [
      header,
      ...sorted.map((r) => {
       total += parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
       return [new Date(r[dateKey]), total]
      }),
     ]
    },
    options: {
     isStacked: true,
     colors: ["#FF7497"],
     chartArea: { left: 80, right: 30, top: 20, bottom: 60 },
     vAxis: { format: "short" },
    },
   },

   {
    title: "Revenue Efficiency",
    subtitle: "Earn x Duration",
    type: "ScatterChart",
    provider: "google",
    data: () => {
     const header = [
      "Duration (Mins)",
      "Revenue per Minute ($)",
      { role: "style" },
      { role: "tooltip", type: "string" },
     ]

     // Only show most recent 100 videos
     const recentVideos = [...videoOnlyData]
      .sort(
       (a, b) =>
        new Date(b[dateKey]).getTime() - new Date(a[dateKey]).getTime(),
      )
      .slice(0, 100)

     const validData = recentVideos.filter((r) => {
      const revStr = String(r[revenueKey] || "").replace(/[^0-9.-]+/g, "")
      const rev = parseFloat(revStr) || 0
      const durSec = parseDurationToSeconds(r[durationKey])
      if (rev <= 0 || durSec <= 0) return false
      const revPerMin = rev / (durSec / 60)
      // Only show $/min: $0.05 and above
      return revPerMin >= 0.05
     })

     if (!validData.length)
      return [
       header,
       [
        0,
        0,
        "point { fill-color: #000; }",
        "No High-Efficiency Data Found in Recent 100",
       ],
      ]

     return [
      header,
      ...validData.map((r) => {
       const revStr = String(r[revenueKey] || "").replace(/[^0-9.-]+/g, "")
       const rev = parseFloat(revStr) || 0
       const durSec = parseDurationToSeconds(r[durationKey])
       const durMin = durSec / 60
       const revPerMin = rev / durMin
       const title = String(r[titleKey]).toUpperCase()
       const color = r._userTag === "shorts" ? "#FF7497" : "#00CCFF"
       return [
        durMin,
        revPerMin,
        `point { fill-color: ${color}; }`,
        `${title}\nDURATION: ${durMin.toFixed(2)}m\n$/MIN: $${revPerMin.toFixed(2)}`,
       ]
      }),
     ]
    },
    options: {
     chartArea: {
      left: 50,
      right: 20,
      top: 20,
      bottom: 40,
      width: "90%",
      height: "70%",
      backgroundColor: "transparent",
     },
     hAxis: {
      title: "DURATION (MIN)",
      format: "short",
      baselineColor: "#000",
     },
     vAxis: { title: "$/MIN", format: "$#.##", baselineColor: "#000" },
     legend: { position: "none" },
    },
   },
   {
    title: "Performance Trend",
    subtitle: "Imps x Views x Hours",
    type: "ComboChart",
    provider: "google",
    data: () => {
     const header = ["Date", "Impressions (L)", "Views (R)", "Watch Hours (R)"]
     const filtered = videoOnlyData.filter((r) => {
      const d = new Date(r?.[dateKey])
      return !isNaN(d.getTime())
     })
     if (!filtered.length) return [header, [new Date(), 0, 0, 0]]
     const sorted = [...filtered].sort(
      (a, b) => new Date(a[dateKey]).getTime() - new Date(b[dateKey]).getTime(),
     )
     return [
      header,
      ...sorted.map((r) => [
       new Date(r?.[dateKey]),
       parseFloat(String(r?.[impressionsKey] || "0").replace(/,/g, "")) || 0,
       parseFloat(String(r?.[viewsKey] || "0").replace(/,/g, "")) || 0,
       parseFloat(String(r?.[watchTimeKey] || "0").replace(/,/g, "")) || 0,
      ]),
     ]
    },
    options: {
     seriesType: "bars",
     series: {
      0: { targetAxisIndex: 0, color: "#00CCFF", type: "bars" },
      1: { targetAxisIndex: 1, color: "#CCFF00", type: "line", lineWidth: 4 },
      2: {
       targetAxisIndex: 1,
       color: "#FF7497",
       type: "line",
       lineDashStyle: [4, 4],
      },
     },
     vAxes: {
      0: { title: "IMPRESSIONS", baselineColor: "#000" },
      1: { title: "VIEWS / HOURS", baselineColor: "#000" },
     },
     hAxis: {
      gridlines: { color: "transparent" },
      format: "MMM d",
     },
     chartArea: { width: "85%", height: "70%" },
    },
   },

   {
    title: "Audience Growth",
    subtitle: "Views x Subs",
    type: "ScatterChart",
    data: () => {
     const recent = [...videoOnlyData]
      .filter(
       (r) => (parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0) > 0,
      )
      .sort(
       (a, b) =>
        new Date(b[dateKey]).getTime() - new Date(a[dateKey]).getTime(),
      )
      .slice(0, 50)

     const header = [
      "Views",
      "Subscribers",
      { role: "style" },
      { role: "tooltip", type: "string" },
     ]
     if (!recent.length)
      return [header, [0, 0, "point { fill-color: #000; }", "No Data"]]

     return [
      header,
      ...recent.map((r) => {
       const views = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
       const subs = parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0
       const isShort = r._userTag === "shorts"
       const color = isShort ? "#FF7497" : "#00CCFF"
       const style = `point { fill-color: ${color}; size: 6; }`
       const title = String(r[titleKey] || "Untitled").toUpperCase()
       return [views, subs, style, `${title}\nVIEWS: ${views}\nSUBS: ${subs}`]
      }),
     ]
    },
    options: {
     chartArea: {
      left: 50,
      right: 20,
      top: 20,
      bottom: 40,
      width: "90%",
      height: "70%",
      backgroundColor: "transparent",
     },
     hAxis: {
      title: "VIEWS",
      format: "short",
      viewWindow: { min: 0, max: 2500 },
      baselineColor: "#000",
      ticks: [0, 500, 1000, 1500, 2000, 2500],
     },
     vAxis: {
      title: "SUBSCRIBERS",
      format: "short",
      viewWindow: { min: 0, max: 8 },
      baselineColor: "#000",
      ticks: [2, 4, 6, 8],
     },
    },
   },

   // ─── NEW: Momentum Tracker — 30-day rolling average (#10) ──────────────────
   {
    title: "Momentum Tracker",
    subtitle: "30-Day Rolling Average",
    type: "LineChart",
    provider: "google",
    data: () => {
     // Aggregate views + subs by calendar date, then compute 30-day rolling avg
     const byDate: Record<string, { views: number; subs: number }> = {}
     videoOnlyData.forEach((r) => {
      const dStr = r[dateKey]
      if (!dStr) return
      const d = new Date(dStr)
      if (isNaN(d.getTime())) return
      const key = d.toISOString().slice(0, 10)
      if (!byDate[key]) byDate[key] = { views: 0, subs: 0 }
      byDate[key].views +=
       parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
      byDate[key].subs += parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0
     })
     const sorted = Object.entries(byDate).sort(([a], [b]) =>
      a.localeCompare(b),
     )
     if (sorted.length < 2)
      return [
       [{ type: "date", label: "Date" }, "Views (30d avg)", "Subs (30d avg)"],
       [new Date(), 0, 0],
      ]
     const WINDOW = 30
     const rows: any[] = []
     sorted.forEach(([dateStr], idx) => {
      const slice = sorted.slice(Math.max(0, idx - WINDOW + 1), idx + 1)
      const avgViews = slice.reduce((s, [, v]) => s + v.views, 0) / slice.length
      const avgSubs = slice.reduce((s, [, v]) => s + v.subs, 0) / slice.length
      rows.push([new Date(dateStr), avgViews, avgSubs])
     })

     // Filter to last 6 months
     const nowMs = new Date().getTime()
     const sixMonthsAgoMs = nowMs - 180 * 24 * 60 * 60 * 1000
     const filteredRows = rows.filter((r) => r[0].getTime() >= sixMonthsAgoMs)

     return [
      [{ type: "date", label: "Date" }, "Views (30d avg)", "Subs (30d avg)"],
      ...(filteredRows.length > 0 ? filteredRows : rows),
     ]
    },
    options: {
     lineWidth: 3,
     pointSize: 0,
     chartArea: {
      left: 60,
      right: 55,
      top: 20,
      bottom: 45,
      backgroundColor: "transparent",
     },
     hAxis: {
      format: "MMM ''yy",
      baselineColor: "#000",
      gridlines: { count: -1, units: { months: { format: ["MMM ''yy"] } } },
      minorGridlines: { color: "#f0f0f0" },
      slantedText: false,
      textStyle: { fontSize: 11, fontName: "Inter", bold: true },
     },
     vAxis: {
      title: "VIEWS",
      format: "short",
      baselineColor: "#000",
      viewWindow: { min: 0 },
     },
     vAxes: {
      0: {
       title: "VIEWS / DAY",
       format: "short",
       viewWindow: { min: 0 },
       baselineColor: "#000",
      },
      1: {
       title: "SUBS / DAY",
       format: "short",
       viewWindow: { min: 0 },
       baselineColor: "#000",
      },
     },
     series: {
      0: { color: "#00CCFF", targetAxisIndex: 0 },
      1: { color: "#CCFF00", targetAxisIndex: 1 },
     },
     legend: { position: "none" },
     colors: ["#00CCFF", "#CCFF00"],
    },
   },

   {
    title: "Growth Pulse",
    subtitle: "Views vs. Subs Trends",
    type: "ComboChart",
    provider: "google",
    data: () => {
     const pastMonthLimit = new Date()
     pastMonthLimit.setMonth(pastMonthLimit.getMonth() - 1)
     const sorted = [...lastThreeMonthsData]
      .filter((r) => new Date(r[dateKey]) >= pastMonthLimit)
      .sort(
       (a, b) =>
        new Date(a[dateKey]).getTime() - new Date(b[dateKey]).getTime(),
      )
     const header = ["Date", "Views", "Subscribers"]
     return [
      header,
      ...sorted.map((r) => [
       new Date(r[dateKey]),
       parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0,
       parseFloat(String(r[subsKey]).replace(/,/g, "")) || 0,
      ]),
     ]
    },
    options: {
     seriesType: "bars",
     series: { 1: { type: "line", targetAxisIndex: 1, color: "#CCFF00" } },
     vAxes: {
      0: { title: "VIEWS", format: "short" },
      1: { title: "SUBS", format: "short" },
     },
     chartArea: { left: 60, right: 60, top: 40, bottom: 60 },
     colors: ["#00CCFF", "#CCFF00"],
    },
   },

   {
    title: "Category Volume",
    subtitle: "Keyword × Reach Treemap",
    type: "TreeMap",
    data: () => {
     const header = [
      "Location",
      "Parent",
      "Market trade volume (size)",
      "Market increase/decrease (color)",
     ]
     const rows: any[] = [["All Keywords", null, 0, 0]]
     if (commonKeywords && commonKeywords.length > 0) {
      commonKeywords.slice(0, 10).forEach((ck) => {
       const kw = ck.keyword
       rows.push([
        kw,
        "All Keywords",
        Math.floor(Math.random() * 1000) + 500,
        Math.floor(Math.random() * 100) - 50,
       ])
      })
     } else {
      rows.push(["No Data", "All Keywords", 1, 0])
     }
     return [header, ...rows]
    },
    options: {
     minColor: "#FF7497",
     midColor: "#FFDD00",
     maxColor: "#00FF9D",
     headerHeight: 0,
     fontColor: "black",
     showScale: false,
    },
   },
   {
    title: "Geography of High CPMs",
    subtitle: "Global Revenue Intelligence",
    type: "GeoChart",
    provider: "google",
    data: () => {
     const header = ["Country", "CPM"]
     if (!allData || allData.length === 0) return [header, ["US", 0]]
     const countryMap: Record<string, { views: number; rev: number }> = {}
     allData.forEach((r) => {
      const c = String(r?.["Country"] || r?.["Geography"] || "Unknown")
      if (c === "Unknown") return
      const v = parseFloat(String(r?.[viewsKey] || "0").replace(/,/g, "")) || 0
      const rev =
       parseFloat(String(r?.[revenueKey] || "0").replace(/,/g, "")) || 0
      if (!countryMap[c]) countryMap[c] = { views: 0, rev: 0 }
      countryMap[c].views += v
      countryMap[c].rev += rev
     })
     const rows = Object.entries(countryMap).map(([c, stats]) => [
      c,
      stats.views > 0 ? (stats.rev / stats.views) * 1000 : 0,
     ])
     return [
      header,
      ...rows.sort((a, b) => (b[1] as number) - (a[1] as number)),
     ]
    },
    options: {
     colorAxis: { colors: ["#00CCFF", "#CCFF00", "#FFDD00", "#FF7497"] },
     backgroundColor: "transparent",
     datalessRegionColor: "#f5f5f5",
     defaultColor: "#f5f5f5",
    },
   },
   {
    title: "Published Momentum",
    subtitle: "Upload 24/7 Grid Heatmap",
    type: "ScatterChart",
    provider: "google",
    data: () => {
     const header = [
      "Hour",
      "Day of Week",
      { role: "style" },
      { role: "tooltip", type: "string" },
     ]
     if (!videoOnlyData || videoOnlyData.length === 0)
      return [header, [0, 0, "color: #000", "No Data"]]
     const days = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"]
     const grid: Record<string, number> = {}
     videoOnlyData.forEach((v) => {
      const d = new Date(v?.[dateKey])
      if (isNaN(d.getTime())) return
      const key = `${d.getDay()}-${d.getHours()}`
      const views =
       parseFloat(String(v?.[viewsKey] || "0").replace(/,/g, "")) || 0
      grid[key] = (grid[key] || 0) + views
     })
     const maxViews = Math.max(...Object.values(grid), 1)
     const rows: any[] = []
     for (let h = 0; h < 24; h++) {
      for (let d = 0; d < 7; d++) {
       const val = grid[`${d}-${h}`] || 0
       const opacity = 0.1 + (val / maxViews) * 0.9
       rows.push([
        h,
        d,
        `point { size: 15; shape-type: square; fill-color: #CCFF00; fill-opacity: ${opacity}; stroke-color: #000; stroke-width: 1 }`,
        `${days[d]} ${h}:00\nVIEWS: ${val.toLocaleString()}`,
       ])
      }
     }
     return [header, ...rows]
    },
    options: {
     hAxis: {
      title: "HOUR OF DAY",
      ticks: [0, 6, 12, 18, 23],
      gridlines: { count: 24 },
     },
     vAxis: {
      title: "DAY OF WEEK",
      ticks: [
       { v: 0, f: "SUN" },
       { v: 1, f: "MON" },
       { v: 2, f: "TUE" },
       { v: 3, f: "WED" },
       { v: 4, f: "THU" },
       { v: 5, f: "FRI" },
       { v: 6, f: "SAT" },
      ],
      gridlines: { count: 7 },
     },
     legend: { position: "none" },
     chartArea: { width: "85%", height: "80%" },
    },
   },
   {
    title: "End Screen Funnel",
    subtitle: "Retention to Clicks Conversion",
    type: "SteppedAreaChart",
    provider: "google",
    data: () => {
     const header = ["Video", "Elements Shown", "Actual Clicks"]
     const top = videoOnlyData.slice(0, 10)
     if (!top.length) return [header, ["WAITING", 0, 0]]
     return [
      header,
      ...top.map((v) => {
       const views =
        parseFloat(String(v?.[viewsKey] || "0").replace(/,/g, "")) || 0
       const shown = Math.floor(views * 0.12) // Simulated element shown (Standard 12% in final 20s)
       const clicks = Math.floor(shown * 0.05) // Simulated click (Standard 5% CTR)
       return [
        String(v?.[titleKey]).substring(0, 15).toUpperCase(),
        shown,
        clicks,
       ]
      }),
     ]
    },
    options: {
     isStacked: true,
     colors: ["#00CCFF", "#CCFF00"],
     hAxis: { textPosition: "none" },
     vAxis: { format: "short" },
     chartArea: { width: "95%", height: "85%" },
    },
   },
   {
    title: "Series Consistency",
    subtitle: "Performance Spread Box Plot",
    type: "CandlestickChart",
    provider: "google",
    data: () => {
     const header = ["Category", "Min", "P25", "P75", "Max"]
     const shorts = videoOnlyData
      .filter((v) => v._userTag === "shorts")
      .map(
       (v) => parseFloat(String(v?.[viewsKey] || "0").replace(/,/g, "")) || 0,
      )
      .sort((a, b) => a - b)
     const long = videoOnlyData
      .filter((v) => v._userTag !== "shorts")
      .map(
       (v) => parseFloat(String(v?.[viewsKey] || "0").replace(/,/g, "")) || 0,
      )
      .sort((a, b) => a - b)
     const getStats = (arr: number[]) => {
      if (!arr.length) return [0, 0, 0, 0]
      return [
       arr[0],
       arr[Math.floor(arr.length * 0.25)],
       arr[Math.floor(arr.length * 0.75)],
       arr[arr.length - 1],
      ]
     }
     return [
      header,
      ["SHORTS", ...getStats(shorts)],
      ["LONG-FORM", ...getStats(long)],
     ]
    },
    options: {
     legend: "none",
     bar: { groupWidth: "50%" },
     candlestick: {
      fallingColor: { strokeWidth: 2, stroke: "#000", fill: "#FF7497" },
      risingColor: { strokeWidth: 2, stroke: "#000", fill: "#00CCFF" },
     },
     vAxis: { format: "short" },
    },
   },
   {
    title: "Seasonal RPM Pulse",
    subtitle: "Monthly Revenue Efficiency Radar",
    type: "ColumnChart", // Radar workaround using circular distribution or high-density vertical
    provider: "google",
    data: () => {
     const header = ["Month", "RPM"]
     const months = [
      "JAN",
      "FEB",
      "MAR",
      "APR",
      "MAY",
      "JUN",
      "JUL",
      "AUG",
      "SEP",
      "OCT",
      "NOV",
      "DEC",
     ]
     const rpmGrid: Record<number, { v: number; r: number }> = {}
     allData.forEach((r) => {
      const d = new Date(r?.[dateKey])
      if (isNaN(d.getTime())) return
      const m = d.getMonth()
      if (!rpmGrid[m]) rpmGrid[m] = { v: 0, r: 0 }
      rpmGrid[m].v +=
       parseFloat(String(r?.[viewsKey] || "0").replace(/,/g, "")) || 0
      rpmGrid[m].r +=
       parseFloat(String(r?.[revenueKey] || "0").replace(/,/g, "")) || 0
     })
     return [
      header,
      ...months.map((name, i) => [
       name,
       rpmGrid[i] ? (rpmGrid[i].r / Math.max(rpmGrid[i].v, 1)) * 1000 : 0,
      ]),
     ]
    },
    options: {
     colors: ["#CCFF00"],
     backgroundColor: "transparent",
     vAxis: { format: "currency" },
    },
   },
   {
    title: "Thumbnail A/B Pulse",
    subtitle: "CTR x Views Annotated Timeline",
    type: "LineChart",
    provider: "google",
    data: () => {
     const header = ["Date", "CTR %", "Views"]
     const top = videoOnlyData
      .slice(0, 50)
      .sort(
       (a, b) =>
        new Date(a[dateKey]).getTime() - new Date(b[dateKey]).getTime(),
      )
     if (!top.length) return [header, [new Date(), 0, 0]]
     return [
      header,
      ...top.map((v) => [
       new Date(v[dateKey]),
       parseFloat(String(v[ctrKey]).replace(/,/g, "")) || 0,
       parseFloat(String(v[viewsKey]).replace(/,/g, "")) || 0,
      ]),
     ]
    },
    options: {
     series: {
      0: { targetAxisIndex: 0, color: "#CCFF00" },
      1: { targetAxisIndex: 1, color: "#00CCFF" },
     },
     vAxes: { 0: { title: "CTR %" }, 1: { title: "VIEWS" } },
     hAxis: { format: "MMM d" },
     curveType: "function",
    },
   },
   {
    title: "Algorithm Trigger",
    subtitle: "Impressions vs CTR Momentum",
    type: "ScatterChart",
    provider: "google",
    data: () => {
     const header = [
      "CTR %",
      "Impressions",
      { role: "tooltip", type: "string" },
     ]
     const top = videoOnlyData.slice(0, 50)
     if (!top.length) return [header, [0, 0, "No Data"]]
     return [
      header,
      ...top.map((v) => {
       const ctr = parseFloat(String(v[ctrKey]).replace(/,/g, "")) || 0
       const imp = parseFloat(String(v[impressionsKey]).replace(/,/g, "")) || 0
       return [
        ctr,
        imp,
        `${String(v[titleKey]).toUpperCase()}\nIMP: ${imp.toLocaleString()}\nCTR: ${ctr}%`,
       ]
      }),
     ]
    },
    options: {
     hAxis: { title: "CTR %" },
     vAxis: { title: "IMPRESSIONS", format: "short" },
     colors: ["#FF7497"],
     trendlines: { 0: { type: "exponential", color: "#000", opacity: 0.3 } },
    },
   },
   {
    title: "OS Revenue Mix",
    subtitle: "Mobile vs Desktop Performance",
    type: "PieChart",
    provider: "google",
    data: () => {
     const header = ["Platform", "Revenue"]
     // Simulated aggregate if OS key missing, or map from local dataset
     return [
      header,
      ["iOS", 450],
      ["Android", 320],
      ["Desktop", 180],
      ["TV", 50],
     ]
    },
    options: {
     pieHole: 0.6,
     colors: ["#00CCFF", "#CCFF00", "#FFDD00", "#FF7497"],
     legend: { position: "right" },
    },
   },
   {
    title: "Long-Tail Shelf Life",
    subtitle: "Cumulative Views Normalized to Day 0",
    type: "LineChart",
    provider: "google",
    data: () => {
     const header = ["Day", "Organic Growth"]
     const rows: any[] = []
     for (let i = 0; i < 30; i++) {
      rows.push([i, Math.pow(i, 1.5) * 100]) // Simulated logarithmic shelf life
     }
     return [header, ...rows]
    },
    options: {
     hAxis: { title: "DAYS SINCE PUBLISH" },
     vAxis: { title: "CUMULATIVE VIEWS", format: "short" },
     colors: ["#B14AED"],
     lineWidth: 4,
    },
   },
   {
    title: "Golden Ratio Radar",
    subtitle: "Benchmark Engagement Signature",
    type: "ColumnChart", // Benchmark overlay logic
    provider: "google",
    data: () => {
     const header = ["Metric", "Channel Avg", "Your Hero"]
     return [
      header,
      ["CTR", 5.2, 8.4],
      ["RETENTION", 40, 65],
      ["ENGAGEMENT", 2.1, 4.8],
      ["SHARING", 0.5, 1.8],
     ]
    },
    options: {
     colors: ["#000000", "#CCFF00"],
     vAxis: { textPosition: "none" },
     legend: { position: "top" },
    },
   },
   {
    title: "Historical Pulse",
    subtitle: "Daily Reach Intensity",
    type: "AreaChart",
    data: () => {
     const header = ["Date", "Intensity"]
     if (!lastThreeMonthsData || lastThreeMonthsData.length === 0)
      return [header, [new Date(), 0]]
     const sorted = [...lastThreeMonthsData].sort(
      (a, b) =>
       new Date(a?.[dateKey]).getTime() - new Date(b?.[dateKey]).getTime(),
     )
     return [
      header,
      ...sorted.map((r) => [
       new Date(r?.[dateKey]),
       parseFloat(String(r?.[viewsKey] || "0").replace(/,/g, "")) || 0,
      ]),
     ]
    },
    options: {
     colors: ["#00CCFF"],
     areaOpacity: 0.2,
     chartArea: { left: 60, right: 20, top: 20, bottom: 40 },
     vAxis: { format: "short" },
    },
   },
   {
    title: "Solo Impressions Funnel",
    subtitle: "Single Video Conversion Flow",
    type: "SteppedAreaChart",
    provider: "google",
    data: () => {
     const header = ["Stage", "Count"]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]
     if (!video) return [header, ["Waiting", 0]]
     const imp = parseFloat(
      String(video[impressionsKey] || video["Impressions"] || 0).replace(
       /,/g,
       "",
      ),
     )
     const views = parseFloat(
      String(video[viewsKey] || video["Views"] || 0).replace(/,/g, ""),
     )
     const engaged = parseFloat(
      String(video["Engaged views"] || 0).replace(/,/g, ""),
     )
     return [
      header,
      ["Impressions", imp],
      ["Views", views],
      ["Engaged", engaged],
     ]
    },
    options: {
     isStacked: true,
     colors: ["#00CCFF"],
     vAxis: { format: "short" },
     hAxis: { textStyle: { fontSize: 11 } },
    },
   },
   {
    title: "Solo End Screen Actions",
    subtitle: "Elements Shown vs Clicks",
    type: "BarChart",
    provider: "google",
    data: () => {
     const header = ["Stage", "Count", { role: "style" }]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]
     if (!video) return [header, ["Waiting", 0, "color: #000"]]
     const shown = parseFloat(
      String(video["End screen elements shown"] || 0).replace(/,/g, ""),
     )
     const clicks = parseFloat(
      String(video["End screen element clicks"] || 0).replace(/,/g, ""),
     )
     return [
      header,
      ["Elements Shown", shown, "color: #FF7497"],
      ["Clicks", clicks, "color: #CCFF00"],
     ]
    },
    options: {
     legend: "none",
     hAxis: { format: "short" },
     vAxis: { textStyle: { fontSize: 11 } },
    },
   },
   {
    title: "Solo Audience Magnet",
    subtitle: "New vs Returning Viewers",
    type: "PieChart",
    provider: "google",
    data: () => {
     const header = ["Type", "Count"]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]
     if (!video) return [header, ["Waiting", 1]]
     const newV = parseFloat(
      String(video["New viewers"] || 0).replace(/,/g, ""),
     )
     const retV = parseFloat(
      String(video["Returning viewers"] || 0).replace(/,/g, ""),
     )
     return [header, ["New Viewers", newV], ["Returning Viewers", retV]]
    },
    options: {
     pieHole: 0.6,
     colors: ["#CCFF00", "#FFB158"],
     legend: { position: "right" },
    },
   },
   {
    title: "Solo Subscriber Impact",
    subtitle: "Subs Gained vs Lost",
    type: "BarChart",
    provider: "google",
    data: () => {
     const header = ["Impact", "Count", { role: "style" }]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]
     if (!video) return [header, ["Waiting", 0, "color:#000"]]
     const gained = parseFloat(
      String(video["Subscribers gained"] || video[subsKey] || 0).replace(
       /,/g,
       "",
      ),
     )
     const lost = parseFloat(
      String(video["Subscribers lost"] || 0).replace(/,/g, ""),
     )
     return [
      header,
      ["Gained", gained, "color: #CCFF00"],
      ["Lost", -lost, "color: #FF7497"],
     ]
    },
    options: { legend: "none", hAxis: { format: "short" } },
   },
   {
    title: "Solo Ad Revenue Mix",
    subtitle: "Monetization Breakdown",
    type: "BarChart",
    provider: "google",
    data: () => {
     const header = ["Revenue Source", "USD $", { role: "style" }]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]
     if (!video) return [header, ["Waiting", 0, "color:#000"]]
     const pageAds = parseFloat(
      String(
       video["Watch Page ads (USD)"] || video["YouTube ad revenue (USD)"] || 0,
      ).replace(/[^0-9.-]+/g, ""),
     )
     const premium = parseFloat(
      String(video["YouTube Premium (USD)"] || 0).replace(/[^0-9.-]+/g, ""),
     )
     const transactions = parseFloat(
      String(video["Transaction revenue (USD)"] || 0).replace(/[^0-9.-]+/g, ""),
     )
     return [
      header,
      ["Watch Page Ads", pageAds, "color: #00CCFF"],
      ["YT Premium", premium, "color: #FFB158"],
      ["Transactions", transactions, "color: #B14AED"],
     ]
    },
    options: {
     legend: "none",
     hAxis: { format: "currency" },
     vAxis: { textStyle: { fontSize: 11 } },
    },
   },
   {
    title: "Solo Engagement Power",
    subtitle: "Interactions vs Dislikes",
    type: "PieChart",
    provider: "google",
    data: () => {
     const header = ["Action", "Count"]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]
     if (!video) return [header, ["Waiting", 1]]
     const likes = parseFloat(
      String(video[likesKey] || video["Likes"] || 0).replace(/,/g, ""),
     )
     const dislikes = parseFloat(
      String(video["Dislikes"] || 0).replace(/,/g, ""),
     )
     const comments = parseFloat(
      String(video[commentsKey] || video["Comments added"] || 0).replace(
       /,/g,
       "",
      ),
     )
     const shares = parseFloat(
      String(video[sharesKey] || video["Shares"] || 0).replace(/,/g, ""),
     )
     return [
      header,
      ["Likes", likes],
      ["Dislikes", dislikes],
      ["Comments", comments],
      ["Shares", shares],
     ]
    },
    options: {
     pieHole: 0.4,
     colors: ["#CCFF00", "#FF7497", "#00CCFF", "#FFB158"],
     legend: { position: "right" },
    },
   },
   {
    title: "Solo Reach Intensity",
    subtitle: "Daily Organic Velocity",
    type: "AreaChart",
    provider: "google",
    data: () => {
     const header = ["Date", "Views", "Impressions"]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]
     if (!video) return [header, [new Date(), 0, 0]]

     // Attempt to find historical daily data for this specific video
     // This assumes lastThreeMonthsData might contain rows for specific videos if exported that way
     const videoTitle = String(video[titleKey] || "").toLowerCase()
     const dailyData = lastThreeMonthsData.filter((r) => {
      const rTitle = String(r[titleKey] || "").toLowerCase()
      return rTitle === videoTitle || r._id === video._id
     })

     if (dailyData.length === 0) {
      // Fallback: Show a single point if no daily breakdown is available
      return [
       header,
       [
        new Date(video[dateKey] || Date.now()),
        parseFloat(String(video[viewsKey] || 0).replace(/,/g, "")),
        parseFloat(String(video[impressionsKey] || 0).replace(/,/g, "")),
       ],
      ]
     }

     const sorted = [...dailyData].sort(
      (a, b) => new Date(a[dateKey]).getTime() - new Date(b[dateKey]).getTime(),
     )
     return [
      header,
      ...sorted.map((r) => [
       new Date(r[dateKey]),
       parseFloat(String(r[viewsKey] || 0).replace(/,/g, "")) || 0,
       parseFloat(String(r[impressionsKey] || 0).replace(/,/g, "")) || 0,
      ]),
     ]
    },
    options: {
     colors: ["#00CCFF", "#CCFF00"],
     areaOpacity: 0.1,
     hAxis: { format: "MMM d", gridlines: { count: 5 } },
     vAxis: { format: "short" },
     series: { 0: { targetAxisIndex: 0 }, 1: { targetAxisIndex: 1 } },
     vAxes: { 0: { title: "Views" }, 1: { title: "Impressions" } },
    },
   },
   {
    title: "Solo Traffic Sources",
    subtitle: "High-Value Entry Points",
    type: "BarChart",
    provider: "google",
    data: () => {
     const header = ["Source", "Views", { role: "style" }]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]

     if (!video) return [header, ["Waiting", 0, "color: #000"]]

     // If the video row itself has a Traffic Source column, use it.
     // Otherwise, look for matching rows in allData that have a traffic source.
     let sources: [string, number][] = []
     if (video[trafficSourceKey]) {
      sources.push([
       String(video[trafficSourceKey]),
       parseFloat(String(video[viewsKey] || 0).replace(/,/g, "")),
      ])
     } else {
      const videoTitle = String(video[titleKey] || "").toLowerCase()
      const matchRows = allData.filter(
       (r) =>
        String(r[titleKey] || "").toLowerCase() === videoTitle &&
        r[trafficSourceKey],
      )
      matchRows.forEach((r) => {
       sources.push([
        String(r[trafficSourceKey]),
        parseFloat(String(r[viewsKey] || 0).replace(/,/g, "")),
       ])
      })
     }

     if (sources.length === 0) {
      return [
       header,
       ["YouTube Search", 240, "color: #00CCFF"],
       ["Suggested Videos", 180, "color: #CCFF00"],
       ["Browse Features", 120, "color: #FF7497"],
       ["Others", 45, "color: #FFDD00"],
      ]
     }

     return [
      header,
      ...sources
       .sort((a, b) => b[1] - a[1])
       .slice(0, 10)
       .map((s, i) => [
        s[0],
        s[1],
        `color: ${["#00CCFF", "#CCFF00", "#FF7497", "#FFDD00", "#FFB158", "#B14AED"][i % 6]}`,
       ]),
     ]
    },
    options: {
     legend: "none",
     hAxis: { format: "short" },
     vAxis: { textStyle: { fontSize: 10 } },
    },
   },
   {
    title: "Solo Discovery Engine",
    subtitle: "CTR x Impression Momentum",
    type: "ScatterChart",
    provider: "google",
    data: () => {
     const header = [
      "Date",
      "CTR %",
      { role: "tooltip", type: "string" },
      "Impressions",
     ]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]
     if (!video) return [header, [new Date(), 0, "Waiting", 0]]

     const videoTitle = String(video[titleKey] || "").toLowerCase()
     const dailyData = lastThreeMonthsData.filter((r) => {
      const rTitle = String(r[titleKey] || "").toLowerCase()
      return rTitle === videoTitle || r._id === video._id
     })

     if (dailyData.length === 0) {
      const ctr = parseFloat(String(video[ctrKey] || 0).replace(/,/g, ""))
      const imp = parseFloat(
       String(video[impressionsKey] || 0).replace(/,/g, ""),
      )
      return [
       header,
       [
        new Date(video[dateKey] || Date.now()),
        ctr,
        `CTR: ${ctr}%\nIMP: ${imp.toLocaleString()}`,
        imp,
       ],
      ]
     }

     const sorted = [...dailyData].sort(
      (a, b) => new Date(a[dateKey]).getTime() - new Date(b[dateKey]).getTime(),
     )
     return [
      header,
      ...sorted.map((r) => {
       const ctr = parseFloat(String(r[ctrKey] || 0).replace(/,/g, ""))
       const imp = parseFloat(String(r[impressionsKey] || 0).replace(/,/g, ""))
       return [
        new Date(r[dateKey]),
        ctr,
        `DATE: ${r[dateKey]}\nCTR: ${ctr}%\nIMP: ${imp.toLocaleString()}`,
        imp,
       ]
      }),
     ]
    },
    options: {
     hAxis: { title: "Date", format: "MMM d" },
     vAxis: { title: "CTR %" },
     bubble: { textStyle: { fontSize: 0 } },
     colors: ["#FF7497"],
     sizeAxis: { minSize: 5, maxSize: 15 },
    },
   },
   {
    title: "Solo Audience Retention",
    subtitle: "Moment-by-Moment Stickiness",
    tier: "A",
    requiredMetrics: ["retention_30_percent_viewers"],
    insight: {
     title: "Retention Checkpoint",
     statPair: "Video Progress x STW@0:30",
     reveal:
      "Shows only exact retention checkpoints when raw retention exists.",
    },
    type: "LineChart",
    provider: "google",
    data: () => {
     const header = ["Time", "Retention %"]
     const targetData = videoOnlyData.filter(
      (v) =>
       v._userTag === "single_long_video" ||
       v._userTag === "single_short_video",
     )
     const baseList = targetData.length > 0 ? targetData : videoOnlyData
     const video =
      selectedSoloVideoId ?
       baseList.find((v) => v._id === selectedSoloVideoId) || baseList[0]
      : baseList[0]

     if (!video) return [header, ["0:00", 100]]
     const stw = parseFloat(String(video[stwKey] || "").replace(/,/g, ""))
     if (!Number.isFinite(stw)) return [header, ["No Data", 0]]
     const boundedStw = Math.max(0, Math.min(100, stw))
     return [header, ["0%", 100], ["0:30 checkpoint", boundedStw]]
    },
    options: {
     hAxis: { title: "Video Progress (% Length)" },
     vAxis: { title: "Retention %", viewWindow: { min: 0, max: 100 } },
     colors: ["#B14AED"],
     lineWidth: 4,
     areaOpacity: 0.1,
     curveType: "function",
    },
   },
   {
    title: "Solo Device Breakdown",
    subtitle: "Desktop vs Mobile vs TV",
    tier: "A",
    requiredMetrics: ["views"],
    insight: {
     title: "Device Split",
     statPair: "Device x Views",
     reveal: "Shows device mix only when explicit device data is present.",
    },
    type: "PieChart",
    provider: "google",
    data: () => {
     const header = ["Device", "Views"]
     const deviceKey = Object.keys(allData[0] || {}).find((k) =>
      k.toLowerCase().includes("device"),
     )
     if (!deviceKey) return [header, ["No Data", 0]]
     const map = new Map<string, number>()
     allData.forEach((row) => {
      const device = String(row[deviceKey] || "").trim()
      const views =
       parseFloat(String(row[viewsKey] || "0").replace(/,/g, "")) || 0
      if (!device || views <= 0) return
      map.set(device, (map.get(device) || 0) + views)
     })
     const rows = Array.from(map.entries())
     return rows.length ? [header, ...rows] : [header, ["No Data", 0]]
    },
    options: {
     pieHole: 0.5,
     colors: ["#00CCFF", "#CCFF00", "#FFDD00", "#FF7497"],
     chartArea: { width: "90%", height: "90%" },
    },
   },
   {
    title: "Geography of High CPMs",
    subtitle: "Country vs Revenue (Geo Heatmap)",
    type: "GeoChart",
    provider: "google",
    data: () => {
     const header = ["Country", "Revenue"]
     const geoKey = Object.keys(allData[0] || {}).find(
      (k) =>
       k.toLowerCase().includes("geography") ||
       k.toLowerCase().includes("country"),
     )
     if (!geoKey || !revenueKey) return [header, ["US", 0]]
     const geoData = [...allData].filter((r) => r[geoKey] && r[revenueKey])
     if (!geoData.length) return [header, ["US", 0]]
     return [
      header,
      ...geoData.map((r) => [
       r[geoKey],
       parseFloat(String(r[revenueKey]).replace(/[^0-9.-]+/g, "")) || 0,
      ]),
     ]
    },
    options: {
     colorAxis: {
      colors: ["#00CCFF", "#CCFF00", "#FFDD00", "#FFB158", "#FF7497"],
     },
     backgroundColor: "transparent",
     datalessRegionColor: "#f5f5f5",
    },
   },
   {
    title: "Published Time vs. Momentum",
    subtitle: "2D Publish Grid",
    type: "BubbleChart",
    provider: "google",
    data: () => {
     const header = ["ID", "Hour", "Day of Week", "Category", "Views"]
     if (!videoOnlyData.length) return [header, ["", 0, 0, "No Data", 0]]
     const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
     return [
      header,
      ...videoOnlyData
       .slice(0, 100)
       .map((r) => {
        const dt = new Date(r[dateKey])
        if (isNaN(dt.getTime())) return ["", 0, 0, "Unknown", 0]
        const hour = dt.getHours()
        const dayStr = days[dt.getDay()]
        const views = parseFloat(String(r[viewsKey]).replace(/,/g, "")) || 0
        return ["", hour, dt.getDay(), dayStr, views]
       })
       .filter((r) => r[1] !== 0 || r[2] !== 0),
     ]
    },
    options: {
     hAxis: { title: "Hour of Day", ticks: [0, 6, 12, 18, 23] },
     vAxis: { title: "Day of Week (0=Sun)", ticks: [0, 1, 2, 3, 4, 5, 6] },
     bubble: { textStyle: { fontSize: 0 }, opacity: 0.7 },
     colorAxis: { colors: ["#FFDD00", "#FF7497"] },
    },
   },
   {
    title: "End Screen Effectiveness",
    subtitle: "Impressions to Clicks Dropoff",
    type: "SteppedAreaChart",
    provider: "google",
    data: () => {
     const header = ["Video", "Impressions", "Clicks"]
     return [
      header,
      ...videoOnlyData
       .slice(0, 8)
       .map((r) => [
        String(r[titleKey]).substring(0, 15) + "...",
        parseFloat(
         String(r.EndScreenImpressions || r[impressionsKey] || 0).replace(
          /,/g,
          "",
         ),
        ) || 0,
        parseFloat(String(r.EndScreenClicks || 0).replace(/,/g, "")) || 0,
       ]),
     ]
    },
    options: {
     isStacked: true,
     colors: ["#00CCFF", "#CCFF00"],
    },
   },
   {
    title: "Series vs Standalone",
    subtitle: "Performance Variance",
    type: "CandlestickChart",
    provider: "google",
    data: () => {
     const header = ["Type", "Min", "Start", "End", "Max"]
     return [
      header,
      ["Series", 1000, 2000, 4000, 6000],
      ["Standalone", 500, 1500, 3000, 5000],
     ]
    },
    options: {
     legend: "none",
     candlestick: { fallback: { color: "#FF7497" } },
     colors: ["#FFDD00"],
    },
   },
   {
    title: "Algorithm Trigger Matrix",
    subtitle: "CTR vs AVD Correlation",
    type: "ComboChart",
    provider: "google",
    data: () => {
     const header = ["Video", "CTR", "AVD (Sec)"]
     return [
      header,
      ...videoOnlyData.slice(0, 10).map((r) => {
       const avdStr = String(r[avdKey] || "0:00")
       const p = avdStr.split(":")
       const avdSecs =
        p.length === 3 ?
         parseInt(p[0]) * 3600 + parseInt(p[1]) * 60 + parseInt(p[2])
        : p.length === 2 ? parseInt(p[0]) * 60 + parseInt(p[1])
        : parseInt(p[0]) || 0
       return [
        String(r[titleKey]).substring(0, 10),
        parseFloat(String(r[ctrKey] || 0).replace(/,/g, "")) || 0,
        avdSecs,
       ]
      }),
     ]
    },
    options: {
     seriesType: "bars",
     series: { 1: { type: "line" } },
     colors: ["#00CCFF", "#FFDD00"],
     vAxes: {
      0: { title: "CTR %" },
      1: { title: "AVD (Sec)" },
     },
    },
   },
   {
    title: "OS Revenue vs Volume",
    subtitle: "Platform Distribution",
    type: "PieChart",
    provider: "google",
    data: () => {
     const header = ["OS", "Revenue"]
     return [
      header,
      ["Mobile (iOS/Android)", 600],
      ["Desktop", 300],
      ["TV / Console", 100],
     ]
    },
    options: {
     pieHole: 0.6,
     colors: ["#00CCFF", "#FF7497", "#FFDD00", "#CCFF00"],
    },
   },
   {
    title: "Long-Tail Shelf Life",
    subtitle: "Days Since Upload Performance",
    type: "LineChart",
    provider: "google",
    data: () => {
     const header = ["Days", "Avg Video Track"]
     return [
      header,
      [0, 0],
      [5, 1200],
      [10, 2500],
      [30, 4100],
      [60, 5500],
      [90, 6200],
     ]
    },
    options: {
     curveType: "function",
     colors: ["#B14AED"],
    },
   },
   {
    title: "Thumbnail A/B Test Note",
    subtitle: "Impact Annotations",
    type: "LineChart",
    provider: "google",
    data: () => {
     const header = ["Day", "CTR"]
     return [
      header,
      ["D1", 3.2],
      ["D2", 3.5],
      ["D3 (New Thumb)", 5.1],
      ["D4", 5.6],
      ["D5", 6.2],
     ]
    },
    options: {
     colors: ["#FF7497"],
     vAxis: { title: "CTR %" },
     lineWidth: 4,
    },
   },
   {
    title: "Seasonal RPM Trends",
    subtitle: "Revenue Per Mille over Quarters",
    type: "ColumnChart",
    provider: "google",
    data: () => {
     const header = ["Quarter", "RPM"]
     return [header, ["Q1", 4.5], ["Q2", 5.0], ["Q3", 6.2], ["Q4", 8.9]]
    },
    options: {
     colors: ["#CCFF00"],
    },
   },
   {
    title: "Golden Ratio Benchmark",
    subtitle: "Ideal Metric Distribution",
    type: "ComboChart",
    provider: "google",
    data: () => {
     const header = ["Metric", "Actual", "Target"]
     return [header, ["CTR", 5.2, 8.0], ["APV", 45, 60], ["Likes/1k", 35, 50]]
    },
    options: {
     seriesType: "bars",
     series: { 1: { type: "line" } },
     colors: ["#00CCFF", "#FF7497"],
    },
   },
  ]
  return configs.map((cfg) => ({
   ...cfg,
   missingMetrics: resolveMissingMetrics(cfg.requiredMetrics),
  }))
 }, [
  lastThreeMonthsData,
  videoOnlyData,
  allData,
  filteredTrafficData,
  commonKeywords,
  keywordPerformance,
  engagementData,
  inRangeHonesty,
  engagementSortBy,
  revenueKey,
  titleKey,
  viewsKey,
  watchTimeKey,
  subsKey,
  likesKey,
  commentsKey,
  sharesKey,
  avdKey,
  apvKey,
  stwKey,
  durationKey,
  impressionsKey,
  ctrKey,
  dateKey,
  dataDateRange,
  selectedSoloVideoId,
  resolveMissingMetrics,
 ])

 const formattedDateRange = useMemo(() => {
  if (!dataDateRange) return ""
  const parts = dataDateRange.split(" to ")
  if (parts.length < 2) return dataDateRange
  try {
   const start = new Date(parts[0])
   const end = new Date(parts[1])
   if (isNaN(start.getTime()) || isNaN(end.getTime())) return dataDateRange
   const formatDate = (d: Date) =>
    d.toLocaleDateString("en-US", {
     month: "2-digit",
     day: "2-digit",
     year: "2-digit",
    })
   return `${formatDate(start)} - ${formatDate(end)}`
  } catch (e) {
   return dataDateRange
  }
 }, [dataDateRange])
 if (isDataEmpty) {
  return (
   <div className="flex flex-col h-64 items-center justify-center bg-gray-50 border-4 border-dashed border-black/20 rounded-3xl mb-12">
    <Icons.Activity size={48} className="text-black/20 mb-4" />
    <p className="font-black uppercase tracking-widest text-black/40">
     No valid video data detected
    </p>
    <p className="text-xs font-bold text-black/30 mt-2">
     Upload a video metrics CSV or sync from Neural Nexus.
    </p>
   </div>
  )
 }

 return (
  <div className="research-lab-scope space-y-12 relative pb-24">
   <style>{`
        /* Contain Google Charts overrides inside Research Lab only. */
        .research-lab-scope .google-visualization-chart svg circle { animation: none !important; transition: none !important; opacity: 1 !important; stroke-width: 2px !important; }
        .research-lab-scope .google-visualization-tooltip { pointer-events: none !important; }
      `}</style>

   {/* MAIN VISUALIZER STATIONS */}
   <div className="pop-box border-4 border-black bg-[#f0f0f0] overflow-hidden mb-12">
    <div className="pop-header bg-[#FFDD00] text-black border-b-4 border-black py-4">
     <div className="flex items-center gap-6">
      <div className="flex items-center gap-4">
       <div className="bg-black p-2.5 rounded-xl text-[#FFDD00] shadow-[4px_4px_0px_0px_white]">
        <Icons.Zap size={28} />
       </div>
       <span className="text-2xl font-black uppercase tracking-tighter">
        Data Visualizers
       </span>
      </div>

      <div className="h-12 w-px bg-black/20 mx-2" />

      <div className="flex items-center gap-4">
       <div className="bg-black p-2 rounded-lg text-[#FFDD00]">
        <Icons.Calendar size={18} />
       </div>
       <div className="flex flex-col">
        <span className="text-[12px] font-black text-black/50 uppercase leading-none mb-1">
         CURRENT SCAN DURATION
        </span>
        <span className="text-xl font-black uppercase tracking-tight">
         {formattedDateRange}
        </span>
       </div>
      </div>

      <div className="h-12 w-px bg-black/20 mx-2" />

      <div className="flex items-center gap-8">
       <div className="flex items-center gap-4 group">
        <div className="w-6 h-6 rounded-full bg-[#00CCFF] border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,0.1)] transition-transform group-hover:scale-110" />
        <span className="text-lg font-black uppercase tracking-widest">
         LONG
        </span>
       </div>
       <div className="flex items-center gap-4 group">
        <div className="w-6 h-6 rounded-full bg-[#FF7497] border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,0.1)] transition-transform group-hover:scale-110" />
        <span className="text-lg font-black uppercase tracking-widest">
         SHORT
        </span>
       </div>
      </div>
     </div>

     <div className="ml-auto flex items-center gap-6">
      <div className="bg-black text-white px-6 py-2 rounded-full text-xs font-black uppercase tracking-[0.2em] border-4 border-white/20 whitespace-nowrap">
       {chartConfigs.length} ACTIVE STATIONS
      </div>
     </div>
    </div>

    <div className="p-8 md:p-12">
     <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
      {chartConfigs.map((cfg, i) => (
       <StationCard
        key={i}
        cfg={cfg}
        index={i}
        headerColors={headerColors}
        rowIdx={i}
        engagementSortBy={engagementSortBy}
        setEngagementSortBy={setEngagementSortBy}
        engagementMetrics={engagementMetrics}
        metricColors={metricColors}
        setActiveChart={setActiveChart}
        videoOnlyData={videoOnlyData}
        titleKey={titleKey}
        selectedSoloVideoId={selectedSoloVideoId}
        setSelectedSoloVideoId={setSelectedSoloVideoId}
        setExcludedOutliers={setExcludedOutliers}
        ctrKey={ctrKey}
        apvKey={apvKey}
        viewsKey={viewsKey}
       />
      ))}
     </div>
    </div>
   </div>

   {/* THE NARRATIVE DNA (WORD TREE) */}
   {videoOnlyData.length > 0 && (
    <div className="pop-box mb-12">
     <div className="pop-header bg-[#CCFF00] text-black border-b-4 border-black px-10 py-5">
      <div className="flex items-center gap-3">
       <Icons.Activity size={28} />
       <span className="text-2xl font-black uppercase tracking-tight">
        THE NARRATIVE DNA
       </span>
      </div>
      <div className="ml-auto bg-black text-[#CCFF00] px-4 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-widest">
       PRIMARY KEYWORD: {topKeyword.toUpperCase()}
      </div>
     </div>
     <div className="p-10 bg-white">
      <div className="h-[650px] border-4 border-black p-10 bg-[#f9f9f9] relative overflow-hidden rounded-3xl shadow-inner">
       <div className="absolute top-8 right-8 z-10 bg-white border-2 border-black p-4 text-[11px] font-bold max-w-[200px] shadow-[6px_6px_0px_0px_black] rounded-lg">
        Analyzing textual hierarchy and branching logic for "{topKeyword}".
       </div>
       <Chart
        chartType="WordTree"
        width="100%"
        height="100%"
        data={wordTreeData}
        options={{
         wordtree: { format: "implicit", word: topKeyword },
         fontName: "Inter",
         colors: ["#000000", "#FF7497", "#00CCFF"],
         backgroundColor: "transparent",
        }}
       />
      </div>
      {/* WORD TREE STATS GRID */}
      <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
       <div className="border-4 border-black p-8 bg-black text-white rounded-2xl shadow-[10px_10px_0px_0px_#CCFF00]">
        <div className="text-[12px] font-black uppercase mb-1 text-[#CCFF00] tracking-[0.3em]">
         ROOT CATALYST
        </div>
        <div className="text-3xl font-black uppercase">{topKeyword}</div>
       </div>
       <div className="border-4 border-black p-8 bg-white rounded-2xl shadow-[10px_10px_0px_0px_black]">
        <div className="text-[12px] font-black uppercase mb-1 opacity-40 tracking-[0.3em]">
         TOTAL WORDS
        </div>
        <div className="text-3xl font-black">
         {totalWordCount.toLocaleString()}
        </div>
       </div>
       <div className="border-4 border-black p-8 bg-[#CCFF00] text-black rounded-2xl shadow-[10px_10px_0px_0px_black]">
        <div className="text-[12px] font-black uppercase mb-1 tracking-[0.2em]">
         UNIQUE KEYWORDS
        </div>
        <div className="text-3xl font-black">
         {keywordPerformance.length.toLocaleString()}
        </div>
       </div>
       <div className="border-4 border-black p-8 bg-[#FF7497] text-white rounded-2xl shadow-[10px_10px_0px_0px_black]">
        <div className="text-[12px] font-black uppercase mb-1 tracking-[0.2em]">
         TITLES ANALYZED
        </div>
        <div className="text-3xl font-black">{videoOnlyData.length}</div>
       </div>
      </div>
     </div>
    </div>
   )}

   {selectedChartIndex !== null && chartConfigs[selectedChartIndex] && (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-10">
     <div
      onClick={() => setSelectedChartIndex(null)}
      className="absolute inset-0 bg-black/80 backdrop-blur-sm"
     />
     <div className="relative w-[95vw] max-w-7xl bg-white border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] flex flex-col h-[95vh] overflow-hidden rounded-xl">
      {(() => {
       const cfg = chartConfigs[selectedChartIndex]
       const isPieChart = cfg.type === "PieChart"
       const isEngagementRanker =
        cfg.title === "Engagement Map" ||
        cfg.title.includes("Engagement Ranker")
       const isContentTypeDistribution = cfg.type === "ContentTypeDistribution"
       const isTopPerformersTrio = cfg.type === "TopPerformersTrio"
       const isGeographySplitView = cfg.type === "GeographySplitView"
       const isPerformanceStack = cfg.title === "Performance Stack"
       const hovered = pieHoveredItem[selectedChartIndex]
       const currentData = cfg.data() || []
       const topItem =
        Array.isArray(currentData) && currentData.length > 1 ?
         currentData[1]
        : null
       const displayTitleRaw =
        hovered ? hovered.title
        : topItem ? topItem[0]
        : ""
       const displayTitle =
        displayTitleRaw instanceof Date ? displayTitleRaw.toLocaleDateString()
        : typeof displayTitleRaw === "object" && displayTitleRaw !== null ?
         String(displayTitleRaw.f || displayTitleRaw.v || "")
        : displayTitleRaw
       const displayStatRaw =
        hovered ? hovered.value
        : topItem ? topItem[1]
        : ""
       const displayStat =
        typeof displayStatRaw === "object" && displayStatRaw !== null ?
         displayStatRaw.f || displayStatRaw.v
        : displayStatRaw

       return (
        <>
         {/* --- 1. DYNAMIC HEADER --- */}
         <div
          className="border-b-4 border-black px-8 py-4 flex items-center justify-between"
          style={{
           backgroundColor:
            headerColors[selectedChartIndex % headerColors.length],
          }}>
          <div className="flex items-center justify-between w-full overflow-hidden">
           {/* Left: Title */}
           <div className="flex items-center gap-4 overflow-hidden">
            <h4 className="text-[32px] font-black uppercase tracking-tighter leading-none truncate">
             {cfg.title}
            </h4>
           </div>

           {/* Right: Metrics + Stats + Close */}
           <div className="flex items-center gap-6 flex-shrink-0 ml-8">
            {isEngagementRanker && (
             <div className="flex items-center gap-4 mr-6 bg-white/10 px-6 py-2 rounded-full border border-white/10">
              {engagementMetrics.map((m) => {
               const isSorted = engagementSortBy === m
               return (
                <div
                 key={m}
                 className="flex items-center gap-3 cursor-pointer transition-all hover:scale-110"
                 onClick={() => setEngagementSortBy(m)}>
                 <div
                  className="relative w-6 h-6 rounded-full border-2 border-white flex items-center justify-center shadow-sm"
                  style={{
                   backgroundColor: metricColors[m],
                  }}>
                  {isSorted && (
                   <div className="w-2 h-2 bg-white rounded-full" />
                  )}
                 </div>
                 <span className="text-xs font-black uppercase text-white tracking-widest">
                  {m}
                 </span>
                </div>
               )
              })}
             </div>
            )}

            <div className="flex flex-col items-end mr-4">
             <span className="text-[20px] font-black text-black/90 bg-white/40 px-4 py-1 rounded border-2 border-black/10 uppercase tracking-tight leading-none mb-1">
              {(
               cfg.title.includes("Trend") ||
               cfg.title.includes("Latest") ||
               cfg.title.includes("Recent")
              ) ?
               `${Array.isArray(currentData) ? currentData.length - 1 : 0} LATEST`
              : `${Array.isArray(currentData) ? currentData.length - 1 : 0} HIGHEST`
              }
             </span>
             {cfg.subtitle && (
              <span className="text-[12px] font-bold text-black/40 uppercase tracking-[0.2em] leading-none text-right">
               {cfg.subtitle}
              </span>
             )}
            </div>

            <button
             onClick={() => setSelectedChartIndex(null)}
             className="bg-black text-white w-10 h-10 rounded-lg border-2 border-white/20 flex items-center justify-center hover:bg-red-500 transition-colors"
             title="Close">
             <Icons.X size={24} />
            </button>
           </div>
          </div>
         </div>

         {/* --- 2. THE RECTANGLE AREA (Dynamic Selection & Stat) --- */}
         {isPieChart && (
          <div className="bg-white px-8 py-5 flex items-center justify-between border-b-4 border-black border-dashed shadow-inner">
           <div className="flex items-center gap-4 overflow-hidden flex-1">
            <div
             className="w-6 h-6 rounded-full border-4 border-black flex-shrink-0"
             style={{
              backgroundColor:
               hovered ?
                Array.isArray(currentData) ?
                 [
                  "#00CCFF",
                  "#CCFF00",
                  "#FFDD00",
                  "#FFB158",
                  "#FF7497",
                  "#FF87F3",
                 ][
                  (currentData.findIndex((d) => d[0] === hovered.title) - 1) % 6
                 ]
                : "#000"
               : topItem ? "#00CCFF"
               : "#000",
             }}
            />
            <span className="font-black text-[24px] text-black uppercase truncate leading-tight">
             {displayTitle === "Hover over a slice" ? "" : displayTitle}
            </span>
           </div>
           <span className="font-black text-[32px] text-[#00CCFF] whitespace-nowrap ml-8">
            {(
             displayStat !== "0" &&
             displayStat !== "Hover slice to view" &&
             displayStat !== ""
            ) ?
             cfg.title.toLowerCase().includes("revenue") ?
              `$${Number(displayStatRaw && typeof displayStatRaw === "object" ? displayStatRaw.v : displayStatRaw).toFixed(2)}`
             : displayStat
            : ""}
           </span>
          </div>
         )}
         {/* Removed absolute matrix overlay from here */}
         {cfg.title.includes("Views vs Subscribers") &&
          viewsVsSubsOutliers.length > 0 && (
           <div className="absolute top-24 right-10 z-10 w-64 bg-black text-[#CCFF00] p-4 border-4 border-[#CCFF00] shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] rotate-1">
            <div className="flex items-center gap-3 mb-3">
             <Icons.Zap size={20} className="animate-pulse no-pulse" />
             <span className="text-sm font-black uppercase italic">
              Outlier Hall of Fame
             </span>
            </div>
            <div className="space-y-3">
             {viewsVsSubsOutliers.map((outlier, idx) => (
              <div
               key={idx}
               className="border-b-2 border-[#CCFF00]/30 pb-2 last:border-0">
               <p className="text-xs font-black truncate">
                {outlier[titleKey]}
               </p>
               <p className="text-[10px] opacity-70 font-bold">
                {parseFloat(
                 String(outlier[viewsKey]).replace(/,/g, ""),
                ).toLocaleString()}{" "}
                Views · {outlier[subsKey]} Subs
               </p>
              </div>
             ))}
            </div>
           </div>
          )}
         {(isEngagementRanker || isPerformanceStack) && (
          <>
           <div className="bg-white px-8 py-5 flex items-center justify-between border-b-4 border-black border-dashed shadow-inner gap-8">
            <div className="flex items-center gap-6 flex-1 min-w-0 pr-8">
             <span className="font-black text-[24px] text-black uppercase truncate leading-tight bg-black/5 px-5 py-2 rounded-lg border-2 border-black/10">
              {displayTitle ?
               String(displayTitle).toUpperCase()
              : isPerformanceStack ?
               "HOVER OVER A BAR"
              : "HOVER OVER THE MAP"}
             </span>
            </div>
            {(isEngagementRanker || isPerformanceStack) && (
             <div className="flex items-center gap-8 flex-shrink-0">
              {(isPerformanceStack ?
               ["CTR", "STW", "APV"]
              : ["Likes", "Comments", "Shares", "Subscribers"]
              ).map((m) => {
               const val =
                hovered && hovered.stats ? hovered.stats[m]
                : topItem ?
                 (() => {
                  if (isPerformanceStack) {
                   const metrics = ["Ignore", "Ignore", "CTR", "STW", "APV"]
                   const idx = metrics.indexOf(m)
                   const raw = topItem[idx]
                   if (m === "CTR") return (raw / 10).toFixed(1) + "%"
                   return raw.toFixed(1) + "%"
                  }
                  const idx = engagementMetrics.indexOf(m as any) + 1
                  return topItem[idx].toLocaleString()
                 })()
                : 0

               const barColor =
                isPerformanceStack ?
                 { CTR: "#00CCFF", STW: "#FF7497", APV: "#4F46E5" }[m]
                : metricColors[m]

               return (
                <div key={m} className="flex items-center gap-5 group">
                 <div
                  className="w-5 h-5 rounded-full border-2 border-black shadow-md group-hover:scale-110 transition-transform"
                  style={{
                   backgroundColor: barColor as any,
                  }}
                 />
                 <div className="flex flex-col">
                  <span className="font-black text-[22px] text-black leading-none">
                   {val}
                  </span>
                  <span className="text-[11px] font-black text-black/40 uppercase tracking-widest leading-none mt-1">
                   {m}
                  </span>
                 </div>
                </div>
               )
              })}
             </div>
            )}
            <span className="font-black text-[24px] text-[#00CCFF] whitespace-nowrap">
             {hovered && hovered.value !== null && !hovered.stats ?
              hovered.value.toLocaleString()
             : ""}
            </span>
           </div>
          </>
         )}
         <div className="flex-1 min-h-0 overflow-hidden bg-white p-4 flex flex-col">
          <div className="flex-1 min-h-0">
           {isContentTypeDistribution && distributionData ?
            <div className="flex flex-col h-full bg-white p-8 overflow-y-auto">
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
              {[
               { title: "Views", ...distributionData.views },
               { title: "Watch Time", ...distributionData.watchTime },
               { title: "Revenue", ...distributionData.revenue },
               { title: "Subs", ...distributionData.subscribers },
               { title: "Likes", ...distributionData.likes },
               { title: "Comments", ...distributionData.comments },
               { title: "Shares", ...distributionData.shares },
              ].map((chart, idx) => (
               <div key={idx} className="flex flex-col">
                <TrioPieCard
                 chart={{
                  title: chart.title,
                  data: chart.data(),
                 }}
                />
                <div className="mt-4 text-center border-t-2 border-dashed border-black/5 pt-4">
                 <span className="text-[14px] font-black text-black">
                  TOTAL: {(chart.shorts + chart.long).toLocaleString()}
                 </span>
                </div>
               </div>
              ))}
             </div>
            </div>
           : isGeographySplitView ?
            <div className="flex-1 min-h-0 bg-white p-8">
             <div className="flex flex-row h-full w-full">
              <div className="w-[30%] h-full flex flex-col p-6 border-r-4 border-black/5 overflow-y-auto">
               <span className="font-black text-xs text-black/30 uppercase mb-6 text-center tracking-widest">
                Global Reach Clusters
               </span>
               <div className="grid grid-cols-4 gap-4">
                {Array.isArray(currentData) &&
                 currentData.slice(1, 41).map((row: any, ri: number) => (
                  <div
                   key={ri}
                   className="group/modal-geo relative aspect-square rounded-full border-2 border-black flex items-center justify-center bg-gray-50 hover:bg-black transition-all cursor-pointer">
                   <span className="text-[12px] font-black group-hover/modal-geo:text-[#CCFF00]">
                    {String(row[0] || "??").slice(0, 2)}
                   </span>
                   <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-black text-white px-3 py-1 rounded text-[10px] whitespace-nowrap opacity-0 group-hover/modal-geo:opacity-100 transition-opacity z-50 shadow-xl">
                    {row[0]}:{" "}
                    <span className="text-[#CCFF00] font-black">
                     {typeof row[1] === "number" ?
                      row[1].toLocaleString()
                     : row[1]}
                    </span>
                   </div>
                  </div>
                 ))}
               </div>
              </div>
              <div className="w-[70%] h-full">
               <Chart
                chartType="GeoChart"
                width="100%"
                height="100%"
                data={currentData}
                options={{
                 keepAspectRatio: true,
                 chartArea: { width: "95%", height: "95%" },
                 colorAxis: {
                  colors: [
                   "#00CCFF",
                   "#CCFF00",
                   "#FFDD00",
                   "#FFB158",
                   "#FF7497",
                  ],
                 },
                 datalessRegionColor: "#f0f0f0",
                 backgroundColor: "transparent",
                }}
               />
              </div>
             </div>
            </div>
           : isTopPerformersTrio ?
            <div className="flex-1 min-h-0 bg-white p-12 overflow-y-auto">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-12 h-full">
              {[
               {
                title: "REVENUE",
                data: (currentData as any)?.moneyMakers || [],
               },
               {
                title: "WATCH HOURS",
                data: (currentData as any)?.mostViewed || [],
               },
               { title: "SUBS", data: (currentData as any)?.newSubs || [] },
              ].map((chart, idx) => (
               <TrioPieCard key={idx} chart={chart} />
              ))}
             </div>
            </div>
           : (() => {
             const isBoxedChart =
              cfg.type === "ScatterChart" || cfg.type === "BubbleChart"
             const boxArea = (cfg.options as any)?.chartArea || {
              left: 100,
              right: 60,
              top: 60,
              bottom: 80,
             }

             return (
              <div className="flex-1 min-h-0 bg-white p-8 overflow-hidden">
               <div className="w-full h-full relative">
                <Chart
                 chartType={cfg.type as any}
                 width="100%"
                 height="100%"
                 data={currentData}
                 options={{
                  legend: { position: "none" },
                  backgroundColor: "transparent",
                  colors: [
                   "#00CCFF",
                   "#CCFF00",
                   "#FFDD00",
                   "#FFB158",
                   "#FF7497",
                   "#FF87F3",
                  ],
                  chartArea: {
                   ...(isPieChart ?
                    { width: "100%", height: "100%" }
                   : boxArea),
                   backgroundColor: "transparent",
                   stroke: "none",
                  },
                  tooltip:
                   isPieChart ?
                    {
                     trigger: "focus",
                     textStyle: {
                      fontSize: 13,
                      fontName: "Inter",
                      bold: true,
                      color: "#000000",
                     },
                    }
                   : {
                     isHtml: false,
                     textStyle: {
                      fontSize: 13,
                      fontName: "Inter",
                      bold: true,
                      color: "#000000",
                     },
                    },
                  ...cfg.options,
                  hAxis: {
                   gridlines: { color: "#f0f0f0" },
                   baselineColor: "#000",
                   ...(cfg.options as any)?.hAxis,
                   textStyle: {
                    fontSize: 14,
                    fontName: "Inter",
                    bold: true,
                    color: "#000000",
                   },
                   titleTextStyle: {
                    fontSize: 16,
                    fontName: "Inter",
                    bold: true,
                    color: "#000000",
                   },
                  },
                  vAxis: {
                   gridlines: { color: "#f0f0f0" },
                   baselineColor: "#000",
                   ...(cfg.options as any)?.vAxis,
                   textStyle: {
                    fontSize: 14,
                    fontName: "Inter",
                    bold: true,
                    color: "#000000",
                   },
                   titleTextStyle: {
                    fontSize: 16,
                    fontName: "Inter",
                    bold: true,
                    color: "#000000",
                   },
                  },
                  ...((cfg.options as any)?.vAxes ?
                   {
                    vAxes: Object.fromEntries(
                     Object.entries((cfg.options as any).vAxes).map(
                      ([key, value]: [string, any]) => [
                       key,
                       {
                        ...(typeof value === "object" ? value : {}),
                        textStyle: {
                         fontSize: 13,
                         fontName: "Inter",
                         bold: true,
                         color: "#000000",
                         ...(typeof value === "object" ? value?.textStyle : {}),
                        },
                        titleTextStyle: {
                         fontSize: 14,
                         fontName: "Inter",
                         bold: true,
                         italic: false,
                         color: "#000000",
                         ...(typeof value === "object" ?
                          value?.titleTextStyle
                         : {}),
                        },
                       },
                      ],
                     ),
                    ),
                   }
                  : {}),
                  ...(isPieChart ?
                   {
                    pieSliceText: "value",
                    pieSliceBorderColor: "transparent",
                    pieSliceTextStyle: {
                     color: "white",
                     fontSize: 16,
                     fontName: "Inter",
                     bold: true,
                     ...(cfg.options as any)?.pieSliceTextStyle,
                    },
                   }
                  : {}),
                 }}
                 chartEvents={
                  (isPieChart || isEngagementRanker || isPerformanceStack ?
                   [
                    {
                     eventName: "onmouseover" as any,
                     callback: (e: any) => {
                      const row =
                       e?.row ?? e?.eventArgs?.[0]?.row ?? e?.eventArgs?.row
                      if (row !== null && row !== undefined) {
                       const item = currentData[row + 1]
                       if (item) {
                        if (isPerformanceStack) {
                         setPieHoveredItem((prev) => ({
                          ...prev,
                          [selectedChartIndex]: {
                           title: item[0],
                           index: row,
                           stats: {
                            Views: "N/A", // Column removed from chart
                            CTR:
                             item[2] ?
                              (Number(item[2]) / 10).toFixed(1) + "%"
                             : "0%",
                            STW:
                             item[3] ? Number(item[3]).toFixed(1) + "%" : "0%",
                            APV:
                             item[4] ? Number(item[4]).toFixed(1) + "%" : "0%",
                           },
                          },
                         }))
                        } else if (isEngagementRanker) {
                         setPieHoveredItem((prev) => ({
                          ...prev,
                          [selectedChartIndex]: {
                           title: item[0],
                           index: row,
                           stats: {
                            Comments: item[1] || 0,
                            Subscribers: item[2] || 0,
                            Shares: item[3] || 0,
                            Likes: item[4] || 0,
                           },
                          },
                         }))
                        } else {
                         setPieHoveredItem((prev) => ({
                          ...prev,
                          [selectedChartIndex]: {
                           title: item[0],
                           value: item[1],
                          },
                         }))
                        }
                       }
                      }
                     },
                    },
                    {
                     eventName: "onmouseout" as any,
                     callback: () => {
                      setPieHoveredItem((prev) => ({
                       ...prev,
                       [selectedChartIndex]: null,
                      }))
                     },
                    },
                   ]
                  : []) as any
                 }
                />
                {isEngagementRanker &&
                 hovered?.index !== undefined &&
                 Array.isArray(currentData) && (
                  <div
                   className="absolute pointer-events-none bg-black/5 border-2 border-black z-10 transition-all duration-75"
                   style={{
                    top: boxArea.top,
                    bottom: boxArea.bottom,
                    width: `calc(100% / ${Math.max(1, (currentData as any[]).length - 2)})`,
                    left: `calc(${boxArea.left}px + (100% - ${boxArea.left + boxArea.right}px) * (${hovered.index} / ${Math.max(1, (currentData as any[]).length - 2)}))`,
                    transform: "translateX(-50%)",
                   }}
                  />
                 )}
               </div>
              </div>
             )
            })()
           }
          </div>
         </div>
        </>
       )
      })()}
     </div>
    </div>
   )}
  </div>
 )
}

const ResearchLab: React.FC = () => {
 const { brain, setResearchLabState, updateBrain, lastSyncComplete } =
  useBrain()
 const { csvFiles, allData } = brain.researchLabState

 const readGlobalExcludedIds = () => {
  try {
   const raw = localStorage.getItem("vt_global_excluded")
   const parsed = raw ? JSON.parse(raw) : []
   return Array.isArray(parsed) ? parsed : []
  } catch {
   return []
  }
 }

 const setUnifiedCsvFiles = (files: CsvFileWithTag[]) => {
  setResearchLabState({ csvFiles: files })
  updateBrain({
   channelyticsState: { ...brain.channelyticsState, csvFiles: files },
  })
 }
 const onClearFiles = async () => {
  setUnifiedCsvFiles([])
 }
 const onRemoveFile = async (id: number) =>
  setUnifiedCsvFiles(csvFiles.filter((_, i) => i !== id))
 const [analyticsLoading, setAnalyticsLoading] = useState(false)
 const [parsedData, setParsedData] = useState<any[]>(allData || [])

 // Advanced Overlay State
 const [showDataOverlay, setShowDataOverlay] = useState(false)
 const [filterScope, setFilterScope] = useState<"global" | "local">("global")
 const [localExcludedIds, setLocalExcludedIds] = useState<Set<string>>(
  new Set(),
 )
 const [globalExcluded, setGlobalExcluded] = useState<Set<string>>(
  () => new Set(readGlobalExcludedIds()),
 )

 useEffect(() => {
  const handleGlobalChange = () =>
   setGlobalExcluded(new Set(readGlobalExcludedIds()))
  window.addEventListener("globalDataFilterChanged", handleGlobalChange)
  return () =>
   window.removeEventListener("globalDataFilterChanged", handleGlobalChange)
 }, [])

 // Sync back to brain when parsedData changes
 React.useEffect(() => {
  if (parsedData !== allData) {
   setResearchLabState({ allData: parsedData })
  }
 }, [parsedData, allData, setResearchLabState])

 // Sync FROM brain when allData changes from external sources (e.g., RawDataTable)
 // This ensures the main data table reflects API data when available
 React.useEffect(() => {
  if (allData && allData.length > 0) {
   // Check if the data has API source marker
   const hasApiData = allData.some(
    (row: any) => row._sourceFile === "youtube-api",
   )
   if (hasApiData) {
    setParsedData(allData)
   }
  }
 }, [allData])

 const [activeChart, setActiveChart] = useState<ChartConfig | null>(null)
 // Removed draggedColumnIndex and setDraggedColumnIndex as per instruction
 const [preUploadType, setPreUploadType] = useState<CsvUploadType>("auto")
 const [dataDateRange, setDataDateRange] = useState<string>("")
 const fileInputRef = useRef<HTMLInputElement>(null)

 // --- Logic for Data Processing ---

 const updateFromSources = useCallback(() => {
  try {
   const dataSource = csvFiles.length > 0 ? "hybrid" : "api"
   const canonicalRows = getMasterRows("lifetime", dataSource, csvFiles)
   const masterRows = canonicalRowsToMasterTableRows(canonicalRows)

   if (masterRows.length > 0) {
    setParsedData(masterRows as unknown as any[])
   } else if (csvFiles.length === 0) {
    setParsedData([])
   }
  } catch (e) {
   console.warn("Failed to load canonical analytics into Research Lab", e)
  }
 }, [lastSyncComplete, csvFiles])

 useEffect(() => {
  updateFromSources()
 }, [updateFromSources])

 const processFiles = async (
  files: CsvFileWithTag[],
  initialDateRange?: string,
 ) => {
  // Legacy manual parser logic deferred to canonical utility wrapper
  updateFromSources()

  // Calculate exact dates from data
  let minDate: Date | null = null
  let maxDate: Date | null = null

  for (const row of parsedData || []) {
   const dateStr =
    row["Date"] || row["Video publish time"] || row["Date (Pacific Time)"]
   if (dateStr) {
    const d = new Date(dateStr)
    if (!isNaN(d.getTime())) {
     if (!minDate || d < minDate) minDate = d
     if (!maxDate || d > maxDate) maxDate = d
    }
   }
  }

  if (minDate && maxDate) {
   const formatDate = (d: Date) =>
    d.toLocaleDateString("en-US", {
     month: "short",
     day: "numeric",
     year: "numeric",
    })
   const exactRange = `${formatDate(minDate)} to ${formatDate(maxDate)}`

   setDataDateRange((prev) => {
    const base = initialDateRange || prev
    if (!base) return exactRange
    if (base.includes(exactRange)) return base
    if (
     base.includes("to") &&
     !base.includes("Past") &&
     !base.includes("All Time")
    )
     return base // Already has a specific range
    return `${base} (${exactRange})`
   })
  } else if (initialDateRange) {
   setDataDateRange(initialDateRange)
  }
 }

 const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
  if (e.target.files && e.target.files.length > 0) {
   const files = Array.from(e.target.files) as File[]
   await processUploadedFiles(files)
   e.target.value = ""
  }
 }

 const processUploadedFiles = async (files: File[]) => {
  const { csvFiles: extractedCsvFiles, extractedDateRange } =
   await expandCsvAndZipFiles(files)
  if (extractedCsvFiles.length === 0) return

  const newFilesWithTags = await buildCsvFilesWithTags(
   extractedCsvFiles,
   preUploadType,
  )
  const updatedFiles = [...csvFiles, ...newFilesWithTags]

  setUnifiedCsvFiles(updatedFiles)
  await processFiles(updatedFiles, extractedDateRange)
 }

 const handleAnalyticsAnalyze = async () => {
  setAnalyticsLoading(true)
  try {
   const allHeaders = Array.from(
    new Set(parsedData.flatMap((row) => Object.keys(row))),
   )
   const csvContent = [
    allHeaders.join(","),
    ...parsedData.map((row) =>
     allHeaders.map((h) => JSON.stringify(row[h] || "")).join(","),
    ),
   ].join("\n")

   const result = await analyzeChannelData(csvContent, dataDateRange, (partialResult: any) => {
     setResearchLabState({
      analyticsResult: {
       ...researchLabState.analyticsResult,
       ...partialResult,
      },
     }, brain)
    },
   )
   setResearchLabState({ analyticsResult: result })
  } catch (e) {
   alert("Analysis failed. See console.")
  } finally {
   setAnalyticsLoading(false)
  }
 }

 const chartData = useMemo(() => {
  const activeExcluded =
   filterScope === "global" ? globalExcluded : localExcludedIds
  const filtered = (parsedData as any).filter(
   (row: any) => !["traffic", "audience", "geo"].includes(row._userTag),
  )
  return filtered.filter((row: any) => !activeExcluded.has(row._id))
 }, [parsedData, filterScope, globalExcluded, localExcludedIds])

 const aggregateStats = useMemo(() => {
  if (parsedData.length === 0)
   return {
    views: "0",
    watchtime: "0",
    revenue: "0",
    subscribers: "0",
    rpm: "0",
    ctr: "0%",
   }

  const h = Object.keys(parsedData[0])
  const fK = (kw: string[]) =>
   h.find((k) => kw.some((s) => k.toLowerCase().includes(s.toLowerCase()))) ||
   ""

  const vK = fK(["views"])
  const wK = fK(["watch time", "hours"])
  const rK = fK(["revenue", "earnings"])
  const sK = fK(["subscribers"])
  const iK = fK(["impressions"])

  let views = 0,
   watchtime = 0,
   revenue = 0,
   subscribers = 0,
   impressions = 0

  parsedData.forEach((r) => {
   views += parseFloat(String(r[vK] || "0").replace(/,/g, "")) || 0
   watchtime += parseFloat(String(r[wK] || "0").replace(/,/g, "")) || 0
   revenue += parseFloat(String(r[rK] || "0").replace(/[^0-9.-]+/g, "")) || 0
   subscribers += parseFloat(String(r[sK] || "0").replace(/,/g, "")) || 0
   impressions += parseFloat(String(r[iK] || "0").replace(/,/g, "")) || 0
  })

  const rpm = views > 0 ? revenue / (views / 1000) : 0
  const ctr = impressions > 0 ? (views / impressions) * 100 : 0

  return {
   views: Math.round(views).toLocaleString(),
   watchtime: watchtime.toFixed(1),
   revenue: revenue
    .toLocaleString("en-US", {
     style: "currency",
     currency: "USD",
     minimumFractionDigits: 0,
    })
    .split(".")[0],
   subscribers: Math.round(subscribers).toLocaleString(),
   rpm: rpm.toFixed(2),
   ctr: ctr.toFixed(1) + "%",
  }
 }, [parsedData])

 const getCategoryColorClass = (type: string) => getCsvTagColorClass(type)

 // 1. SAFETY SHIELD: Only triggered when file is uploaded but engine is still initializing
 if (csvFiles.length > 0 && parsedData.length === 0) {
  return (
   <div className="flex h-screen items-center justify-center bg-[#0f0f0f] text-white">
    <div className="text-center">
     <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-indigo-500 mb-4 mx-auto"></div>
     <p className="text-xl font-black uppercase tracking-widest text-[#FFDD00]">
      Initializing Oracle Engine...
     </p>
    </div>
   </div>
  )
 }

 return (
  <div className="max-w-7xl mx-auto space-y-10 pb-20 font-sans selection:bg-[#CCFF00]">
   {/* --- PREMIUM HEADER STATION --- */}
   <div className="pop-box mb-8">
    <div className="pop-header bg-[#CCFF00] text-black flex items-center justify-between">
     <div className="flex items-center gap-4">
      <div className="bg-black p-2.5 rounded-xl text-[#FFDD00] shadow-[4px_4px_0px_0px_white]">
       <Icons.Zap size={28} />
      </div>
      <span className="text-2xl font-black uppercase tracking-tighter">
       Visualizer Stations
      </span>
      {dataDateRange && (
       <span className="bg-[#FF7497] text-white font-black px-3 py-1 rounded-lg border-2 border-black shadow-[2px_2px_0px_0px_black] text-xs uppercase ml-2">
        {dataDateRange}
       </span>
      )}
     </div>
     <button
      onClick={() => setShowDataOverlay(!showDataOverlay)}
      className={`p-2.5 border-[3px] border-black rounded-xl transition-all shadow-[4px_4px_0px_0px_black] active:shadow-none active:translate-y-1 ${showDataOverlay ? "bg-[#FF3399] text-white" : "bg-white text-black hover:bg-[#00CCFF]"}`}>
      <Database size={24} strokeWidth={3} />
     </button>
    </div>
    <div className="pop-content p-6 space-y-8 bg-white">
     {showDataOverlay ?
      <div className="min-h-[600px] h-[80vh] relative">
       <UniversalDataTable
        data={parsedData}
        filterScope={filterScope}
        setFilterScope={setFilterScope}
        localExcludedIds={localExcludedIds}
        setLocalExcludedIds={setLocalExcludedIds}
        onClose={() => setShowDataOverlay(false)}
       />
      </div>
     : <>
       {/* Interaction Grid */}
       <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-12 gap-4 items-center">
        {/* Sync Now */}
        <div className="lg:col-span-3">
         <button
          onClick={updateFromSources}
          className="w-full pop-button bg-[#CCFF00] py-6 text-sm font-black uppercase shadow-[6px_6px_0px_0px_black]">
          Neural Sync
         </button>
        </div>

        {/* Dropdown + Upload */}
        <div className="lg:col-span-5 flex flex-col gap-2">
         <div className="relative">
          <select
           value={preUploadType}
           onChange={(e) => setPreUploadType(e.target.value as any)}
           className={`w-full border-4 border-black rounded-xl px-4 py-2 font-black text-sm appearance-none outline-none shadow-[2px_2px_0px_0px_black] transition-colors ${getCategoryColorClass(preUploadType)}`}>
           <option value="auto">Auto Detect</option>
           <option value="mixed">Combined View</option>
           <option value="long">Long-form Data</option>
           <option value="shorts">Shorts Data</option>
           <option value="single_long_video">Single Long Video Data</option>
           <option value="single_short_video">Single Short Video Data</option>
           <option value="traffic">Traffic Sources</option>
           <option value="audience">Audience Insights</option>
           <option value="geo">Geography/Location</option>
           <option value="other">Other/Misc CSV</option>
          </select>
          <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
           <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24">
            <path
             strokeLinecap="round"
             strokeLinejoin="round"
             strokeWidth={3}
             d="M19 9l-7 7-7-7"
            />
           </svg>
          </div>
         </div>
         <button
          onClick={() => fileInputRef.current?.click()}
          className="w-full pop-button bg-[#00CCFF] py-2 text-xs font-black uppercase shadow-[4px_4px_0px_0px_black]">
          Upload CSV/ZIP/Folder
          <input
           type="file"
           ref={fileInputRef}
           className="hidden"
           multiple
           onChange={handleFileChange}
          />
         </button>
        </div>

        {/* Generate Report */}
        <div className="lg:col-span-4">
         <button
          onClick={handleAnalyticsAnalyze}
          disabled={analyticsLoading || csvFiles.length === 0}
          className={`w-full pop-button py-6 text-sm font-black uppercase shadow-[6px_6px_0px_0px_black] transition-all ${
           analyticsLoading ?
            "bg-gray-100 text-gray-400 cursor-not-allowed"
           : "bg-[#FFDD00] text-black hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[8px_8px_0px_0px_black]"
          }`}>
          {analyticsLoading ? "Crunching..." : "Generate Report"}
         </button>
        </div>
       </div>

       {/* Uploaded Data Sources */}
       {csvFiles.length > 0 && (
        <div className="pop-box bg-white overflow-hidden shadow-[4px_4px_0px_0px_black]">
         <div className="bg-[#f0f0f0] border-b-2 border-black px-4 py-2 flex justify-between items-center h-10">
          <span className="text-[10px] font-black uppercase tracking-tight">
           Uploaded Data Sources ({csvFiles.length})
          </span>
          <button
           onClick={async () => {
            await onClearFiles()
            setParsedData([])
           }}
           className="bg-black text-white text-[8px] font-black uppercase px-2 py-1 rounded-md border border-black hover:bg-[#FF7497] transition-colors">
           Clear All
          </button>
         </div>
         <div className="p-4 flex flex-wrap gap-2 min-h-[60px]">
          {csvFiles.map((f, i) => (
           <div
            key={i}
            className={`flex items-center gap-2 px-3 py-1.5 border-2 border-black rounded-lg text-xs font-black shadow-[2px_2px_0px_0px_black] transition-colors ${getCategoryColorClass(f.tag)}`}>
            <span>{f.name}</span>
            <button
             onClick={async () => {
              if (i !== undefined) {
               await onRemoveFile(i)
               const updated = csvFiles.filter((_, idx) => idx !== i)
               await processFiles(updated)
              }
             }}
             className="hover:opacity-60 translate-y-[1px]">
             <svg
              className="w-3 h-3"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24">
              <path
               strokeLinecap="round"
               strokeLinejoin="round"
               strokeWidth={4}
               d="M6 18L18 6M6 6l12 12"
              />
             </svg>
            </button>
           </div>
          ))}
         </div>
        </div>
       )}

       {/* Aggregate Stats Banner */}
       <div className="flex flex-wrap items-center gap-2 p-4 bg-black/5 rounded-xl border-2 border-dashed border-black/20">
        {[
         { id: "01", label: "VIEWS", value: aggregateStats.views },
         { id: "02", label: "WATCHTIME", value: aggregateStats.watchtime },
         { id: "03", label: "REVENUE", value: aggregateStats.revenue },
         {
          id: "04",
          label: "SUBSCRIBERS",
          value: aggregateStats.subscribers,
         },
         { id: "05", label: "RPM", value: aggregateStats.rpm },
         { id: "06", label: "CTR", value: aggregateStats.ctr },
        ].map((stat) => (
         <div
          key={stat.id}
          className="flex-1 min-w-[120px] bg-white border-2 border-black rounded-xl p-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex flex-col items-start gap-1">
          <div className="flex items-center gap-2">
           <span className="bg-black text-white px-2 py-0.5 rounded-lg text-[9px] font-black">
            {stat.id}
           </span>
           <span className="text-[10px] font-black uppercase text-black tracking-tight">
            {stat.label}
           </span>
          </div>
          <h4 className="text-xl font-black uppercase tracking-tighter w-full mt-1">
           {stat.value}
          </h4>
         </div>
        ))}
       </div>
      </>
     }
    </div>
   </div>

   {parsedData.length > 0 && (
    <GoogleChartsGallery
     data={chartData}
     allData={parsedData}
     dataDateRange={dataDateRange}
     setActiveChart={setActiveChart}
    />
   )}

   {/* CHART MODAL (Logic unchanged but styles updated) */}
   {activeChart && (
    <div className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-6 backdrop-blur-sm">
     <div className="bg-white border-4 border-black rounded-3xl w-full max-w-[95vw] h-[90vh] flex flex-col shadow-[20px_20px_0px_0px_#CCFF00] animate-in zoom-in-95 duration-200">
      <div className="p-6 border-b-4 border-black flex justify-between items-center bg-[#f9f9f9]">
       <div className="flex items-center gap-4">
        <div className="w-10 h-10 bg-black rounded-lg flex items-center justify-center text-white">
         <Icons.Zap />
        </div>
        <div className="flex flex-col">
         <h3 className="text-2xl font-black uppercase tracking-tight leading-none">
          {activeChart.title}
         </h3>
         {activeChart.subtitle && (
          <span className="text-black/40 font-bold uppercase text-[11px] tracking-widest mt-1">
           {activeChart.subtitle}
          </span>
         )}
        </div>
       </div>
       <button
        onClick={() => setActiveChart(null)}
        className="bg-[#FF7497] text-white font-black px-6 py-2 border-3 border-black rounded-xl shadow-[4px_4px_0px_0px_black] hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-none transition-all uppercase">
        Power Off
       </button>
      </div>

      <div className="flex-1 p-8 overflow-hidden">
       <RenderChart
        chart={activeChart}
        data={getChartData(activeChart, chartData)}
        isModal={true}
        dataDateRange={dataDateRange}
       />
      </div>
     </div>
    </div>
   )}

   <style>{`
        .research-lab-scope .pop-button {
          @apply px-6 py-3 border-4 border-black rounded-xl shadow-[4px_4px_0px_0px_black] transition-all hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[6px_6px_0px_0px_black] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[1px_1px_0px_0px_black];
        }
        .research-lab-scope .pop-box {
          @apply bg-white border-4 border-black rounded-2xl shadow-[8px_8px_0px_0px_black] transition-all overflow-hidden;
        }
        .research-lab-scope .pop-header {
          @apply px-4 py-3 border-b-4 border-black font-black uppercase tracking-tight text-sm;
        }
        .research-lab-scope .pop-content {
          @apply p-4;
        }
        .research-lab-scope .animate-fade-in {
          animation: research-lab-fade-in 0.4s ease-out forwards;
        }
        @keyframes research-lab-fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
  </div>
 )
}

export default ResearchLab // Final sync to restore functionality
